import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import os
import datetime
import concurrent.futures
import re
from collections import Counter

sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import ws_logic #type: ignore
import tmdb_handler #type: ignore

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
# Ošetření vstupu argumentů
ARGS = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
CACHE_WINDOW = xbmcgui.Window(10000)

ADDON_PATH = ADDON.getAddonInfo('path')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

ICONS = {
    'SEARCH': os.path.join(MEDIA_PATH, 'search.png'),
    'FILM': os.path.join(MEDIA_PATH, 'film.png'),
    'HISTORY': os.path.join(MEDIA_PATH, 'history.png'),
    'RESUME': os.path.join(MEDIA_PATH, 'history_resume.png'),
    'WATCHED': os.path.join(MEDIA_PATH, 'history_watched.png'),
    'POPULAR': os.path.join(MEDIA_PATH, 'popular.png'),
    'THEATRE': os.path.join(MEDIA_PATH, 'theatre.png'),
    'CZ': os.path.join(MEDIA_PATH, 'cz.png'),
    'TRANSCRIPT': os.path.join(MEDIA_PATH, 'transcript.png'),
    'CALENDAR': os.path.join(MEDIA_PATH, 'calendar.png'),
    'BOOK': os.path.join(MEDIA_PATH, 'book.png'),
    'OVERLAY_WATCHED': os.path.join(MEDIA_PATH, 'watched.png'),
    'OVERLAY_RESUME': os.path.join(MEDIA_PATH, 'resume.png'),
    '4K': os.path.join(MEDIA_PATH, '4k.png'),
    '1080': os.path.join(MEDIA_PATH, '1080p.png'),
    '720': os.path.join(MEDIA_PATH, '720p.png'),
    'SD': os.path.join(MEDIA_PATH, 'sd.png'),
    'DEF_VIDEO': 'DefaultVideo.png',
    'DEF_FOLDER': 'DefaultFolder.png',
    'SETTINGS': 'DefaultAddonService.png',
    'NEXT': 'DefaultIconNext.png',
    'PREV': 'DefaultIconPrevious.png'
}

def log_debug(msg):
    """Zapíše debug zprávu do Kodi logu"""
    xbmc.log(f"[Webshare Stream Cinema] [main.py]: {msg}", xbmc.LOGINFO)

def get_setting(name):
    """Získá nastavení z addonu"""
    return ADDON.getSetting(name)

def build_url(query):
    """Sestaví URL pro addon"""
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def set_video_info_tag(li, info):
    """
    Nastaví video info tag pro ListItem (Opraveno pro Kodi Nexus/Omega)
    """
    # Zkusíme získat InfoTag (moderní způsob)
    tag = None
    try:
        tag = li.getVideoInfoTag()
    except AttributeError:
        pass

    if tag:
        # Nastavení metadat přes InfoTag (bez warningů)
        if 'title' in info: tag.setTitle(info['title'])
        if 'originaltitle' in info: tag.setOriginalTitle(info['originaltitle'])
        if 'plot' in info: tag.setPlot(info['plot'])
        if 'year' in info: tag.setYear(int(info['year']))
        if 'rating' in info: tag.setRating(float(info['rating']))
        if 'duration' in info: tag.setDuration(int(info['duration'])) # Pozor: setInfo bralo minuty, InfoTag chce často sekundy, ale záleží na verzi
        if 'cast' in info: tag.setCast([xbmc.Actor(name=c) for c in info['cast']])
        if 'genres' in info: tag.setGenres(info['genres'])
        if 'studios' in info: tag.setStudios(info['studios'])
        if 'premiered' in info: tag.setPremiered(info['premiered'])
        
        # Nastavení typu média pro skin
        if 'mediatype' in info:
            tag.setMediaType(info['mediatype'])
    else:
        # Fallback pro starší Kodi
        li.setInfo('video', info)

def create_list_item(label, path, art=None, info=None, is_folder=True, is_playable=False, context_menu=None):
    """Vytvoří a přidá list item do directory"""
    li = xbmcgui.ListItem(label)
    if art:
        if 'icon' not in art or not art['icon']: 
            art['icon'] = ICONS['DEF_FOLDER'] if is_folder else ICONS['DEF_VIDEO']
        if 'thumb' not in art: art['thumb'] = art['icon']
        if 'poster' not in art: art['poster'] = art['icon']
        li.setArt(art)
    if info:
        set_video_info_tag(li, info)
    if is_playable:
        li.setProperty('IsPlayable', 'true')
        is_folder = False
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(HANDLE, path, li, is_folder)

def check_prerequisites(silent=False):
    """Kontrola přihlášení a API klíče"""
    log_debug(f"check_prerequisites(silent={silent})")
    user = get_setting('username')
    tmdb_key = get_setting('tmdb_api_key')
    if not tmdb_key:
        if not silent: ADDON.openSettings()
        return None, None
    token = CACHE_WINDOW.getProperty('ws_token')
    if not token:
        token = ws_logic.login(user, get_setting('password'))
        if not token:
            if not silent: xbmcgui.Dialog().ok('Chyba', 'Chyba přihlášení Webshare.')
            return None, None
        CACHE_WINDOW.setProperty('ws_token', token)
    return token, tmdb_key

def show_account_info():
    """Zobrazí informace o účtu"""
    token, _ = check_prerequisites(silent=False)
    if not token: return
    info = ws_logic.get_user_info(token)
    if info:
        c = "lime" if info['is_vip'] else "red"
        txt = f"Uživatel: {info['username']}\nStav: [COLOR {c}]{'VIP AKTIVNÍ' if info['is_vip'] else 'NEAKTIVNÍ'}[/COLOR]\nExpirace: {info['expire']}"
        xbmcgui.Dialog().ok("Stav účtu", txt)

def run_speed_test():
    """Spustí test rychlosti"""
    token, _ = check_prerequisites()
    if not token: return
    pd = xbmcgui.DialogProgress()
    pd.create('Speed Test', 'Měřím rychlost stahování...')
    
    def update_progress(percent, max, msg=None, abort_check=False):
        if abort_check: return pd.iscanceled()
        display_msg = msg if msg else f"Měřím... {percent}%"
        pd.update(percent, display_msg)
        return pd.iscanceled()
        
    prumer, maximum = ws_logic.measure_download_speed(token, update_progress)
    pd.close()

    if prumer > 0:
        xbmcgui.Dialog().ok("Výsledek", f"Průměrná rychlost: [COLOR lime][B]{prumer} Mbps[/B][/COLOR]\nNejvyšší rychlost: [COLOR lime][B]{maximum} Mbps[/B][/COLOR]")
    elif prumer == -2.0:
        xbmcgui.Dialog().ok("Chyba", "Chyba testu: Síťová chyba.")
    else:
        xbmcgui.Dialog().ok("Chyba", "Chyba testu: Test byl zrušen.")

def main_menu():
    """Hlavní menu"""
    create_list_item('Hledat vše', build_url({'mode':'search_all'}), {'icon': ICONS['SEARCH']})
    create_list_item('Filmy', build_url({'mode':'movies_menu'}), {'icon': ICONS['FILM']})
    create_list_item('Seriály', build_url({'mode':'tv_menu'}), {'icon': ICONS['FILM']})
    create_list_item('Historie', build_url({'mode':'history_menu'}), {'icon': ICONS['HISTORY']})
    create_list_item('Nastavení', build_url({'mode':'settings'}), {'icon': ICONS['SETTINGS']}, is_folder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def movies_menu():
    """Menu pro filmy"""
    create_list_item('Hledat filmy', build_url({'mode':'search_movies'}), {'icon': ICONS['SEARCH']})
    create_list_item('Nově nadabované (CZ)', build_url({'mode':'list_discover', 'type':'dubbed', 'media_type':'movie', 'tmdb_page':'1'}), {'icon': ICONS['CZ']})
    create_list_item('Nově s titulky (CZ)', build_url({'mode':'list_discover', 'type':'subtitled', 'media_type':'movie', 'tmdb_page':'1'}), {'icon': ICONS['TRANSCRIPT']})
    create_list_item('Nejpopulárnější', build_url({'mode':'list_tmdb', 'cat':'movie_popular', 'tmdb_page':'1'}), {'icon': ICONS['POPULAR']})
    create_list_item('Podle roku', build_url({'mode':'years_menu', 'media_type':'movie'}), {'icon': ICONS['CALENDAR']})
    create_list_item('Podle žánru', build_url({'mode':'genres_menu', 'media_type':'movie'}), {'icon': ICONS['BOOK']})
    xbmcplugin.endOfDirectory(HANDLE)

def tv_menu():
    """Menu pro seriály"""
    create_list_item('Hledat seriály', build_url({'mode':'search_tv'}), {'icon': ICONS['SEARCH']})
    create_list_item('Nově nadabované (CZ)', build_url({'mode':'list_discover', 'type':'dubbed', 'media_type':'tv', 'tmdb_page':'1'}), {'icon': ICONS['CZ']})
    create_list_item('Nově s titulky (CZ)', build_url({'mode':'list_discover', 'type':'subtitled', 'media_type':'tv', 'tmdb_page':'1'}), {'icon': ICONS['TRANSCRIPT']})
    create_list_item('Nejpopulárnější', build_url({'mode':'list_tmdb', 'cat':'tv_popular', 'tmdb_page':'1'}), {'icon': ICONS['POPULAR']})
    create_list_item('Podle roku', build_url({'mode':'years_menu', 'media_type':'tv'}), {'icon': ICONS['CALENDAR']})
    create_list_item('Podle žánru', build_url({'mode':'genres_menu', 'media_type':'tv'}), {'icon': ICONS['BOOK']})
    xbmcplugin.endOfDirectory(HANDLE)

def years_menu(media_type='movie'):
    for y in range(datetime.datetime.now().year + 1, 1950, -1):
        create_list_item(str(y), build_url({'mode':'list_discover', 'type':'year', 'media_type':media_type, 'year':str(y), 'tmdb_page':'1'}))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(media_type='movie'):
    for name, gid in tmdb_handler.GENRES.items():
        create_list_item(name, build_url({'mode':'list_discover', 'type':'genre', 'media_type':media_type, 'genre_id':str(gid), 'tmdb_page':'1'}))
    xbmcplugin.endOfDirectory(HANDLE)

def history_menu():
    create_list_item('Pokračovat ve sledování', build_url({'mode':'list_history', 'history_filter':'resume'}), {'icon': ICONS['RESUME']})
    create_list_item('Historie zhlédnutých', build_url({'mode':'list_history', 'history_filter':'watched'}), {'icon': ICONS['WATCHED']})
    create_list_item('Historie vyhledávání', build_url({'mode':'history_search'}), {'icon': ICONS['SEARCH']})
    xbmcplugin.endOfDirectory(HANDLE)

def get_season_languages(tid, clean_title, original_title, season_num, token, tmdb_key):
    """Zjistí jazyky série - používá TMDb seznam epizod (jako list_episodes)"""
    
    # 1. NEJDŘÍV získáme oficiální seznam epizod z TMDb
    eps = tmdb_handler.get_season_episodes(tid, season_num, tmdb_key)
    if not eps:
        return [], set()
    
    # 2. Získáme všechny soubory (stejně jako list_episodes)
    all_files = []
    for tit in [clean_title, original_title]:
        if tit:
            all_files.extend(ws_logic.search_webshare_bulk(f"{tit} s{str(season_num).zfill(2)}", token, 150))
    
    if not all_files:
        return [], set()
    
    # 3. Pro KAŽDOU epizodu z TMDb najdeme nejlepší jazyk (jako list_episodes)
    found_episodes = set()
    season_best_langs = []
    prio = {'CZ': 3, 'CZ TIT': 2, 'SK': 1.5, 'EN': 1}
    
    for e in eps:
        ep_num = e['episode']
        best_lang = ""
        has_file = False
        curr_p = 0
        
        # Projdeme všechny soubory a najdeme validní pro TUTO epizodu
        for f in all_files:
            fn = f.findtext("name")
            if ws_logic.is_valid_file(fn, [clean_title, original_title], 'tv', season=season_num, episode=ep_num):
                has_file = True
                found_episodes.add(ep_num)
                l = ws_logic.detect_lang_code(fn)
                p = prio.get(l, 0.5)
                if p > curr_p:
                    curr_p = p
                    best_lang = l
        
        # Pokud má epizoda soubor, přidáme její nejlepší jazyk
        if has_file and best_lang:
            season_best_langs.append(best_lang)
    
    # 4. Unikátní jazyky série
    unique_langs = list(set(season_best_langs))
    unique_langs.sort(key=lambda x: ws_logic.get_language_priority(x), reverse=True)
    
    return unique_langs, found_episodes

def process_tmdb_item_thread(item, token, tmdb_key, is_search_all, strict_mode=None, history_filter=None):
    if not item: return None
    item.setdefault('is_available', False)
    item.setdefault('lang_label', '')
    item.setdefault('year', '')
    item.setdefault('display_title', item.get('title', 'Unknown'))
    item.setdefault('genres', [])

    try:
        mt = item.get('type', 'movie')
        raw_title = item.get('title', '')
        
        is_cjk = bool(re.search(r'[\u4e00-\u9fff]', raw_title))
        clean_title = re.sub(r'^\[.*?\]\s*', '', raw_title)
        
        titles = [clean_title, item.get('original_title', '')]
        en_title = None
        try:
            en_title = tmdb_handler.get_en_title(item['id'], mt, tmdb_key)
            if en_title and en_title not in titles: titles.append(en_title)
        except: pass
        
        if is_cjk:
            if en_title: display_title = en_title
            elif item.get('original_title') and not re.search(r'[\u4e00-\u9fff]', item.get('original_title', '')): display_title = item.get('original_title')
            else: display_title = clean_title
        else: display_title = clean_title

        if not item.get('year') or not item.get('poster') or not item.get('plot') or not item.get('genres'):
            try:
                details = tmdb_handler.get_details(item['id'], mt, tmdb_key)
                if details:
                    item.update(details)
                    if 'release_date' in details and details['release_date']:
                        item['year'] = details['release_date'][:4]
            except Exception as e: pass

        if history_filter and mt == 'tv':
            try:
                total_eps = item.get('episodes_count', 0)
                watched_count = ws_logic.get_series_progress_stats(item['id'])
                pct = int((watched_count / total_eps) * 100) if total_eps > 0 else 0
                item['series_percent'] = pct
                if history_filter == 'resume':
                    if pct == 0 or pct >= 100: return None
                elif history_filter == 'watched':
                    if pct < 100: return None
            except: return None
                
        avail = False
        lang_priority = {'CZ': 3, 'CZ TIT': 2, 'EN': 1}
        best_priority = 0
        best_lang_label = ""
        found_langs = []

        # === FILMY ===
        if mt == 'movie':
            for q in titles[:3]:
                try:
                    res = ws_logic.search_webshare_bulk(q, token, limit=20)
                    if not res: continue
                    
                    for r in res:
                        fname = r.findtext("name")
                        is_valid = ws_logic.is_valid_file(fname, titles, 'movie', year=item.get('year'))
                        
                        if is_valid:
                            detected = ws_logic.detect_lang_label(fname)
                            
                            # Striktní filtry - OKAMŽITÉ ZAMÍTNUTÍ SOUBORU
                            if strict_mode == 'dubbed' and detected != 'CZ': continue
                            if strict_mode == 'subtitled' and detected != 'CZ TIT': continue

                            found_langs.append(detected)
                            avail = True
                            current_p = lang_priority.get(detected, 1)
                            if current_p > best_priority:
                                best_priority = current_p
                                best_lang_label = detected
                    if best_priority == 3: break
                except Exception as e: pass
            
            # Finální kontrola pro položku jako celek
            if not avail and strict_mode: return None
            if strict_mode == 'dubbed' and best_lang_label != "CZ": return None
            if strict_mode == 'subtitled' and best_lang_label != "CZ TIT": return None

        # === SERIÁLY ===
        elif mt == 'tv':
            seasons_count = item.get('seasons_count', 0)
            if seasons_count == 0:
                try:
                    details = tmdb_handler.get_details(item['id'], 'tv', tmdb_key)
                    seasons_count = details.get('seasons_count', 0)
                except: seasons_count = 0
            
            if seasons_count > 0:
                all_series_langs = []
                # Pokud je striktní režim, neprocházíme tolik sérií, stačí najít shodu
                check_limit = 3 if strict_mode else min(seasons_count + 1, 11)
                
                for season_num in range(1, check_limit):
                    try:
                        unique_langs, found_eps = get_season_languages(item['id'], clean_title, item.get('original_title', ''), season_num, token, tmdb_key)
                        
                        if unique_langs and found_eps:
                            # Filtrace jazyků série
                            if strict_mode == 'dubbed':
                                if 'CZ' in unique_langs:
                                    avail = True
                                    all_series_langs.append('CZ')
                                    break # Stačí nám vědět, že to má dabing
                            elif strict_mode == 'subtitled':
                                if 'CZ TIT' in unique_langs:
                                    avail = True
                                    all_series_langs.append('CZ TIT')
                                    break
                            else:
                                avail = True
                                all_series_langs.extend(unique_langs)
                    except: pass
                
                if avail:
                    unique_series_langs = list(set(all_series_langs))
                    unique_series_langs.sort(key=lambda x: ws_logic.get_language_priority(x), reverse=True)
                    best_lang_label = ", ".join(unique_series_langs)

            if strict_mode == 'dubbed' and 'CZ' not in best_lang_label: return None
            if strict_mode == 'subtitled' and 'CZ TIT' not in best_lang_label: return None
            if strict_mode and not avail: return None

        item['is_available'] = avail
        item['lang_label'] = best_lang_label
        item['display_title'] = f"[{'Film' if mt=='movie' else 'Seriál'}] {display_title}" if is_search_all else display_title
        
        if mt == 'tv' and 'series_percent' not in item:
            try:
                total_eps = item.get('episodes_count', 0)
                watched_count = ws_logic.get_series_progress_stats(item['id'])
                if total_eps > 0 and watched_count > 0:
                    item['series_percent'] = int((watched_count / total_eps) * 100)
            except: pass

        return item
    except Exception as e:
        log_debug(f"process_tmdb_item_thread() exception: {e}")
        return item

def render_content_list(results, token, tmdb_key, strict_mode=None, history_filter=None, progress_bar=None):
    if not results: 
        log_debug("render_content_list() no results")
        return
        
    is_search_all = ARGS.get('mode', [''])[0] == 'search_all'
    
    items_to_process = [i for i in results if 'is_available' not in i]
    already_processed = [i for i in results if 'is_available' in i]
    
    # Pokud máme progress bar, nastavíme počáteční stav pro ověřování
    if progress_bar:
        progress_bar.update(0, "Ověřuji dostupnost streamů...")
    
    if items_to_process:
        total_items = len(items_to_process)
        processed_count = 0
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
            futures = {ex.submit(process_tmdb_item_thread, i, token, tmdb_key, is_search_all, strict_mode, history_filter): i for i in items_to_process}
            
            for f in concurrent.futures.as_completed(futures):
                # Kontrola tlačítka Zrušit
                if progress_bar and progress_bar.iscanceled():
                    break
                    
                try:
                    res = f.result()
                    if res: already_processed.append(res)
                except Exception as ex: pass
                
                # Aktualizace Loading Baru
                if progress_bar:
                    processed_count += 1
                    pct = int((processed_count / total_items) * 100)
                    # Zobrazujeme název právě zpracovávané položky pro lepší UX
                    item_name = futures[f].get('title', '')
                    progress_bar.update(pct, f"Ověřuji: {item_name}")

    already_processed.sort(key=lambda x: str(x.get('year') or ''), reverse=True)

    for i in already_processed:
        mt = i.get('type', 'movie')
        avail = i.get('is_available')
        color = "white" if avail else "gray"

        lang_str = ""
        if avail and i.get('lang_label'):
            lang_code = i['lang_label']
            if ',' in lang_code:
                langs = [l.strip() for l in lang_code.split(',')]
                colored_langs = [f"[COLOR {ws_logic.get_lang_color(l)}]{l}[/COLOR]" for l in langs]
                lang_str = f" [B]({', '.join(colored_langs)})[/B]"
            else:
                l_color = ws_logic.get_lang_color(lang_code)
                lang_str = f" [B][COLOR {l_color}]{lang_code}[/COLOR][/B]"
        elif not avail:
            lang_str = " (Nedostupný)"

        log_debug(f"STRICT? {strict_mode} | Item: {i.get('title','Unknown')} | Available: {avail} | Lang: {lang_str}")
        #log_debug(f"STRICT? {strict_mode}")
        #log_debug(lang_str.find('CZ '))
        #if strict_mode == 'dubbed' and lang_str.find('CZ ') < 0:
        #    log_debug("Jsme v dabingu a není CZ, přeskočím položku.")
        #    continue


        progress_str = ""
        uid = i.get('unique_id', str(i['id']))
        overlay_icon = None

        if mt == 'tv':
            pct = i.get('series_percent', 0)
            if pct > 0:
                progress_str = f" [COLOR gray]({pct}%)[/COLOR]"
                overlay_icon = ICONS['OVERLAY_WATCHED'] if pct >= 100 else ICONS['OVERLAY_RESUME']
        else:
            st = ws_logic.get_watched_status(uid)
            if st:
                if st.get('status') == 'resume':
                    progress_str = f" [COLOR gray]({int(st.get('percentage', 0))}%)[/COLOR]"
                    overlay_icon = ICONS['OVERLAY_RESUME']
                elif st.get('status') == 'watched':
                    progress_str = " [COLOR gray]Zhlédnuto[/COLOR]"
                    overlay_icon = ICONS['OVERLAY_WATCHED']

        y_str = str(i.get('year', ''))
        year_disp = f" ({y_str})" if y_str.isdigit() else ""
        label = f"[COLOR {color}]{i.get('display_title')}{year_disp}{lang_str}{progress_str}[/COLOR]"
        
        # PŘÍPRAVA DAT (vytahujeme data z položky)
        orig_tit = i.get('original_title', '')
        studio = i.get('studio', '')
        release_date = i.get('release_date', '') # YYYY-MM-DD
        formatted_date = ws_logic.format_date_cz(release_date)
        genres_list = i.get('genres', [])
        genres_str = ", ".join(genres_list)
        plot_txt = i.get('plot', '')
        cast_list = i.get('cast', [])
        cast_str = ", ".join(cast_list)

        # === SESTAVENÍ POPISU (FORMÁTOVÁNÍ PRO PANEL) ===
        desc = f"[COLOR gray]{orig_tit}[/COLOR]\n"
        if studio: desc += f"{studio}\n"
        if formatted_date: desc += f"Vydáno: {formatted_date}\n"
        if genres_str: desc += f"{genres_str}\n"
        if mt == 'movie':
            bud = ws_logic.format_currency(i.get('budget'))
            rev = ws_logic.format_currency(i.get('revenue'))
            if i.get('budget') or i.get('revenue'):
                desc += "\n"
                desc += f"Rozpočet: {bud}\n"
                desc += f"Tržby: {rev}\n"
        desc += "\n" 
        desc += f"{plot_txt}\n\n"
        if cast_list:
            desc += f"[B]Hrají:[/B] {cast_str}"
        # ================================================

        info = {
            'title': i.get('display_title'),
            'originaltitle': orig_tit, 
            'plot': desc,
            'rating': i.get('rating', 0),
            'year': int(y_str) if y_str.isdigit() else 0,
            'premiered': release_date,
            'studios': [studio] if studio else [],
            'cast': cast_list,
            'genres': genres_list,
            'mediatype': 'movie' if mt == 'movie' else 'tvshow'
        }
        
        p = i.get('poster') or ICONS['DEF_VIDEO']
        art = {'icon': overlay_icon if overlay_icon else p, 'thumb': p, 'poster': p, 'fanart': i.get('fanart','')}
        
        if mt == 'movie':
            url = build_url({'mode': 'resolve_content', 'media_type': 'movie', 'id': i['id'], 't': i['title'], 'ot': i.get('original_title',''), 'poster': p})
            create_list_item(label, url, art, info, is_playable=True)
        else:
            url = build_url({'mode': 'list_seasons', 'id': i['id'], 't': i['title'], 'ot': i.get('original_title','')})
            create_list_item(label, url, art, info, is_folder=True)

def list_discover(type_filter, media_type, tmdb_page, year=None, genre_id=None):
    """
    Seznam z TMDb discover s Loading Barem, Smart Pagination a CACHE (48h)
    """
    token, k = check_prerequisites()
    if not token: return

    if media_type == 'movie': xbmcplugin.setContent(HANDLE, 'movies')
    elif media_type == 'tv': xbmcplugin.setContent(HANDLE, 'tvshows')

    # Unikátní klíč pro cache
    cache_key = f"disc_{media_type}_{type_filter}_{year}_{genre_id}_{tmdb_page}"
    cached_items = ws_logic.get_cached_data(cache_key)

    # 1. POKUD MÁME DATA V CACHE, POUŽIJEME JE A KONČÍME
    if cached_items:
        # Přidání navigačních tlačítek i při načtení z cache
        current_page = int(tmdb_page)
        #if current_page > 1:
        #    prev_url = build_url({'mode': 'list_discover', 'type': type_filter, 'media_type': media_type, 'tmdb_page': str(current_page - 1), 'year': year, 'genre_id': genre_id})
        #    create_list_item(f"Předchozí strana", prev_url, {'icon': ICONS.get('PREV', ICONS['DEF_FOLDER'])}, is_folder=True)
        
        render_content_list(cached_items, token, k)
        
        next_url = build_url({'mode': 'list_discover', 'type': type_filter, 'media_type': media_type, 'tmdb_page': str(current_page + 1), 'year': year, 'genre_id': genre_id})
        create_list_item(f"Další strana ({current_page + 1})", next_url, {'icon': ICONS.get('NEXT', ICONS['DEF_FOLDER'])}, is_folder=True)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 2. POKUD NEJSOU V CACHE, SPUSTÍME NAČÍTÁNÍ
    current_page = int(tmdb_page)
    target_count = int(get_setting('items_per_page'))
    collected_items = []
    
    params = {}
    strict_mode = None
    if type_filter == 'dubbed':
        params = {'sort_by': 'primary_release_date.desc' if media_type == 'movie' else 'first_air_date.desc', 'vote_count.gte': '5'}
        strict_mode = 'dubbed'
    elif type_filter == 'subtitled':
        params = {'sort_by': 'vote_count.desc'}
        strict_mode = 'subtitled'
    elif type_filter == 'year':
        params = {('primary_release_year' if media_type == 'movie' else 'first_air_date_year'): year, 'sort_by': 'popularity.desc'}
    elif type_filter == 'genre':
        params = {'with_genres': genre_id, 'sort_by': 'popularity.desc'}
    
    pd = xbmcgui.DialogProgress()
    pd.create('Načítám obsah', f'Hledám položky a ověřuji jazyky...')
    
    max_pages_try = 10
    pages_tried = 0
    
    while len(collected_items) < target_count and pages_tried < max_pages_try:
        if pd.iscanceled(): break
        pd.update(int((len(collected_items) / target_count) * 100), f"Načítám stranu {current_page}...\nNalezeno: {len(collected_items)}/{target_count}")
        
        raw_items = tmdb_handler.discover(k, type=media_type, params=params, page=current_page)
        if not raw_items: break
            
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
            futures = {ex.submit(process_tmdb_item_thread, i, token, k, False, strict_mode, None): i for i in raw_items}
            total_in_batch = len(raw_items)
            processed_in_batch = 0
            
            for f in concurrent.futures.as_completed(futures):
                if pd.iscanceled(): break
                processed_in_batch += 1
                base_progress = int((len(collected_items) / target_count) * 100)
                batch_progress = int((processed_in_batch / total_in_batch) * 10)
                pd.update(base_progress + batch_progress, f"Ověřuji streamy (Strana {current_page})...")

                try:
                    res = f.result()
                    if res and res.get('is_available'):
                        collected_items.append(res)
                except: pass
        
        if pd.iscanceled(): break
        if len(collected_items) >= target_count: break
        current_page += 1
        pages_tried += 1

    pd.close()

    # ULOŽENÍ DO CACHE
    if collected_items:
        ws_logic.save_cached_data(cache_key, collected_items)

    # Nepotřebujeme předchozí stranu, protože první tlačítko se vrací o jednu stránku
    #if int(tmdb_page) > 1:
    #    prev_url = build_url({'mode': 'list_discover', 'type': type_filter, 'media_type': media_type, 'tmdb_page': str(int(tmdb_page) - 1), 'year': year, 'genre_id': genre_id})
    #    create_list_item(f"Předchozí strana", prev_url, {'icon': ICONS.get('PREV', ICONS['DEF_FOLDER'])}, is_folder=True)

    render_content_list(collected_items, token, k, strict_mode=strict_mode)
    
    next_url = build_url({'mode': 'list_discover', 'type': type_filter, 'media_type': media_type, 'tmdb_page': str(current_page + 1), 'year': year, 'genre_id': genre_id})
    create_list_item(f"Další strana ({current_page + 1})", next_url, {'icon': ICONS.get('NEXT', ICONS['DEF_FOLDER'])}, is_folder=True)
            
    xbmcplugin.endOfDirectory(HANDLE)

def list_tmdb(cat, tmdb_page):
    """
    Seznam populárního obsahu s Loading Barem a Cache
    """
    token, k = check_prerequisites()
    if not token: return
    
    mt = 'movie' if 'movie' in cat else 'tv'
    if mt == 'movie': xbmcplugin.setContent(HANDLE, 'movies')
    else: xbmcplugin.setContent(HANDLE, 'tvshows')

    # Cache klíč
    cache_key = f"tmdb_{cat}_{tmdb_page}"
    cached_items = ws_logic.get_cached_data(cache_key)

    # 1. ZPRACOVÁNÍ Z CACHE
    if cached_items:
        page = int(tmdb_page)
        #if page > 1:
        #    prev_url = build_url({'mode': 'list_tmdb', 'cat': cat, 'tmdb_page': str(page - 1)})
        #    create_list_item(f"Předchozí strana ({page - 1})", prev_url, {'icon': ICONS.get('PREV', ICONS['DEF_FOLDER'])}, is_folder=True)
            
        render_content_list(cached_items, token, k)
        
        next_url = build_url({'mode': 'list_tmdb', 'cat': cat, 'tmdb_page': str(page + 1)})
        create_list_item(f"Další strana ({page + 1})", next_url, {'icon': ICONS.get('NEXT', ICONS['DEF_FOLDER'])}, is_folder=True)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 2. NAČÍTÁNÍ POKUD NENÍ V CACHE
    page = int(tmdb_page)
    api_cat = 'popular' if 'popular' in cat else 'now_playing'
    
    pd = xbmcgui.DialogProgress()
    pd.create('Načítám obsah', 'Získávám data z TMDb...')
    
    # Stažení dat
    items = tmdb_handler.get_popular(k, mt, api_cat, page=page)
    
    # Zpracování streamů s Progress Barem
    processed_items = []
    if items:
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
            futures = {ex.submit(process_tmdb_item_thread, i, token, k, False, None, None): i for i in items}
            total = len(items)
            done = 0
            
            for f in concurrent.futures.as_completed(futures):
                if pd.iscanceled(): break
                done += 1
                pd.update(int((done/total)*100), f"Ověřuji dostupnost: {done}/{total}")
                
                try:
                    res = f.result()
                    if res: processed_items.append(res)
                except: pass
    
    pd.close()
    
    if processed_items:
        # Seřadit podle roku (volitelné, populární jsou obvykle už seřazené z TMDB, ale pro jistotu)
        # processed_items.sort(key=lambda x: str(x.get('year') or ''), reverse=True)
        ws_logic.save_cached_data(cache_key, processed_items)

    # Navigace a render
    #if page > 1:
    #    prev_url = build_url({'mode': 'list_tmdb', 'cat': cat, 'tmdb_page': str(page - 1)})
    #    create_list_item(f"Předchozí strana ({page - 1})", prev_url, {'icon': ICONS.get('PREV', ICONS['DEF_FOLDER'])}, is_folder=True)

    render_content_list(processed_items, token, k)

    next_url = build_url({'mode': 'list_tmdb', 'cat': cat, 'tmdb_page': str(page + 1)})
    create_list_item(f"Další strana ({page + 1})", next_url, {'icon': ICONS.get('NEXT', ICONS['DEF_FOLDER'])}, is_folder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_history(history_filter='resume'):
    """Seznam z historie"""
    token, k = check_prerequisites()
    if not token: return

    # Historie obsahuje mix, ale pro hezký vzhled nastavíme aspoň 'movies'.
    # Většina skinů si poradí, pokud tam bude seriál, ale primární view bude filmové.
    xbmcplugin.setContent(HANDLE, 'movies')

    items = ws_logic.get_history_items(filter_type=history_filter)
    if not items:
        xbmcgui.Dialog().notification('Info', 'Prázdná historie', xbmcgui.NOTIFICATION_INFO)
        return
    tmdb_res = []
    for i in items:
        rid = str(i['id'])
        cid = rid.split('_')[0] if '_' in rid else rid
        yr = i.get('year')
        yr = '' if str(yr)=='None' else yr
        tmdb_res.append({'id': int(cid), 'type': i['type'], 'title': i['title'], 'original_title': i['title'], 'year': yr, 'poster': i.get('poster',''), 'fanart':'', 'unique_id': i['unique_id']})
    render_content_list(tmdb_res, token, k, history_filter=history_filter)
    xbmcplugin.endOfDirectory(HANDLE)

def list_seasons(tid, t, ot):
    """Seznam sezón seriálu"""
    token, k = check_prerequisites()
    
    # === DŮLEŽITÉ PRO VZHLED PANELU ===
    xbmcplugin.setContent(HANDLE, 'seasons')
    # ==================================
    
    det = tmdb_handler.get_details(tid, 'tv', k)
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    
    s_data = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futures = {ex.submit(check_season_details, tid, i, clean_t, token, ot, k): i for i in range(1, det.get('seasons_count', 0)+1)}
        for f in concurrent.futures.as_completed(futures):
            try:
                s, c, l, eps = f.result()
                s_data[s] = {'count':c, 'lang':l, 'eps':eps}
            except Exception as e: pass

    for i in range(1, det.get('seasons_count', 0)+1):
        d = s_data.get(i, {'count':0, 'lang':'', 'eps':set()})
        avail_count = len(d['eps'])
        
        watched_count = 0
        if avail_count > 0:
            for ep_num in d['eps']:
                uid = f"{tid}_S{i}E{ep_num}"
                st = ws_logic.get_watched_status(uid)
                if st and st.get('status') == 'watched': watched_count += 1
        
        lang_tag = ""
        if d['lang']:
            if ',' in d['lang']:
                langs = [l.strip() for l in d['lang'].split(',')]
                colored_langs = [f"[COLOR {ws_logic.get_lang_color(l)}]{l}[/COLOR]" for l in langs]
                lang_tag = f" [B]({', '.join(colored_langs)})[/B]"
            else:
                l_color = ws_logic.get_lang_color(d['lang'])
                lang_tag = f" [B][COLOR {l_color}]{d['lang']}[/COLOR][/B]"
        pct_str = ""
        overlay = None
        
        if avail_count == 0:
            label = f"[COLOR gray]Série {i} (Nedostupné)[/COLOR]"
        else:
            if watched_count > 0:
                p = int((watched_count / avail_count) * 100)
                pct_str = f" [COLOR gray]({p}%)[/COLOR]"
                overlay = ICONS['OVERLAY_WATCHED'] if p>=100 else ICONS['OVERLAY_RESUME']
            label = f"Série {i}{lang_tag}{pct_str}"
            
        art = {'icon': overlay if overlay else ICONS['DEF_FOLDER']}
        info = {'mediatype': 'season', 'season': i, 'title': f'Série {i}'}
        
        # KONTEXTOVÉ MENU
        context_menu = []
        mark_url = build_url({'mode': 'mark_season_watched', 'id': tid, 's': i, 't': t})
        context_menu.append(('Označit sérii jako zhlédnutou', f'RunPlugin({mark_url})'))

        create_list_item(label, build_url({'mode':'list_episodes','id':tid,'s':i,'t':t,'ot':ot}), art, info=info, is_folder=True, context_menu=context_menu)
    
    xbmcplugin.endOfDirectory(HANDLE)

def check_season_details(tid, s_num, clean_t, token, original_title="", tmdb_key=""):
    unique_langs, found_eps = get_season_languages(tid, clean_t, original_title, s_num, token, tmdb_key)
    lang_str = ", ".join(unique_langs) if unique_langs else ""
    return s_num, len(found_eps), lang_str, found_eps

def list_episodes(tid, s, t, ot):
    """Seznam epizod sezóny s kontextovým menu"""
    token, k = check_prerequisites()
    xbmcplugin.setContent(HANDLE, 'episodes')
    
    try:
        eps = tmdb_handler.get_season_episodes(tid, s, k)
    except Exception as e:
        eps = []

    if not eps:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    
    # Získání souborů
    all_files = []
    try:
        if hasattr(ws_logic, 'get_season_files_bulk'):
            all_files = ws_logic.get_season_files_bulk(token, [clean_t, ot], int(s))
        else:
            for tit in [clean_t, ot]:
                if tit: all_files.extend(ws_logic.search_webshare_bulk(f"{tit} s{str(s).zfill(2)}", token, 150))
    except: pass
    
    for e in eps:
        ep_uid = f"{tid}_S{s}E{e['episode']}"
        
        # Logika pro jazyky souborů (stejná jako dříve)
        best_lang = ""
        has_f = False
        curr_p = 0
        prio = {'CZ':3, 'CZ TIT':2, 'SK':1.5, 'EN':1}
        
        for f in all_files:
            fn = f.findtext("name")
            try:
                if ws_logic.is_valid_file(fn, [clean_t, ot], 'tv', season=s, episode=e['episode']):
                    has_f = True
                    l = ws_logic.detect_lang_code(fn)
                    p = prio.get(l, 0.5)
                    if p > curr_p:
                        curr_p = p
                        best_lang = l
            except: pass
        
        st = ws_logic.get_watched_status(ep_uid)
        is_watched = False
        prog = ""
        overlay = None
        
        if st:
            if st.get('status') == 'watched':
                is_watched = True
                prog = " [COLOR gray]Zhlédnuto[/COLOR]"
                overlay = ICONS['OVERLAY_WATCHED']
            elif st.get('status') == 'resume':
                prog = f" [COLOR gray]({int(st.get('percentage'))}%)[/COLOR]"
                overlay = ICONS['OVERLAY_RESUME']
        
        lang_str = ""
        if has_f and best_lang:
            l_color = ws_logic.get_lang_color(best_lang)
            lang_str = f" [B][COLOR {l_color}]{best_lang}[/COLOR][/B]"
        
        label = f"{e['episode']}. {e['name']}{lang_str}{prog}"
        art = {'thumb': e['thumb'], 'icon': overlay if overlay else (e['thumb'] or ICONS['DEF_VIDEO'])}
        info = {
            'title': e['name'], 
            'plot': e.get('overview', ''), 
            'mediatype': 'episode', 
            'season': int(s), 
            'episode': int(e['episode'])
        }
        
        # --- KONTEXTOVÉ MENU ---
        context_menu = []
        if is_watched:
            # Tlačítko pro ODOZNAČENÍ
            u_url = build_url({'mode': 'mark_ep_unwatched', 'uid': ep_uid})
            context_menu.append(('Odoznačit jako zhlédnuté', f'RunPlugin({u_url})'))
        else:
            # Tlačítko pro OZNAČENÍ
            w_url = build_url({'mode': 'mark_ep_watched', 'uid': ep_uid, 't': f"{clean_t} - {e['name']}"})
            context_menu.append(('Označit jako zhlédnuté', f'RunPlugin({w_url})'))
        # -----------------------

        if has_f:
            create_list_item(label, build_url({'mode':'resolve_content','media_type':'tv','id':tid,'s':s,'e':e['episode'],'t':t,'ot':ot,'en':e['name']}), art, info, is_playable=True, context_menu=context_menu)
        else:
            create_list_item(f"[COLOR gray]{label} (Nedostupné)[/COLOR]", build_url({'mode':'ignore'}), art, info, context_menu=context_menu)
    
    xbmcplugin.endOfDirectory(HANDLE)

def select_and_play_file(files, display_title, uid, media_type, poster=None):
    if not files:
        xbmcgui.Dialog().notification('Webshare', 'Soubory nenalezeny', xbmcgui.NOTIFICATION_INFO, 3000)
        # DŮLEŽITÉ: Musíme říct Kodi, že se nic nepřehrává, jinak zamrzne
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    
    files.sort(key=lambda x: int(x.findtext("size") or 0), reverse=True)
    l_items = []
    
    for f in files:
        n = f.findtext("name")
        qk, ql = ws_logic.detect_quality_label(n)
        ll = ws_logic.detect_lang_code(n)
        
        quality_lang = ws_logic.format_quality_lang_label(qk, ql, ll)
        label = f"{quality_lang} | {ws_logic.format_size(f.findtext('size'))} | {n}"
        
        icon = ICONS['4K'] if qk=="4k" else ICONS['1080'] if qk=="1080p" else ICONS['720'] if qk=="720p" else ICONS['SD']
        
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': icon})
        l_items.append(li)
    
    sel = xbmcgui.Dialog().select("Vyberte kvalitu" if media_type == 'movie' else "Vyberte verzi", l_items)
    
    if sel >= 0:
        f = files[sel]
        play_direct(f.findtext("ident"), display_title, uid, 0, media_type, display_title, f.findtext("ident"), f.findtext("name"), poster=poster)
    else:
        # Pokud uživatel zruší výběr (ESC), musíme také ukončit loading
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def resolve_content(media_type, tid, t, ot, s=None, e=None, en=None, poster=None):
    token, k = check_prerequisites()
    if not token: 
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    
    if media_type == 'tv':
        ep_uid = f"{tid}_S{s}E{e}"
        display_title = f"{clean_t} - {en}"
    else:
        ep_uid = str(tid)
        display_title = clean_t
    
    last_id, last_fn, resume = ws_logic.get_last_played_file(ep_uid)
    if last_id and xbmcgui.Dialog().yesno("Pokračovat?", f"Přehrát naposledy zvolený soubor?\n{last_fn}"):
        play_direct(last_id, display_title, ep_uid, resume, media_type, display_title, last_id, last_fn, poster=poster)
        return
    
    titles = [clean_t, ot]
    if media_type == 'movie':
        try:
            en_title = tmdb_handler.get_en_title(tid, 'movie', k)
            if en_title: titles.append(en_title)
        except: pass
    
    found = []
    valid = []
    
    if media_type == 'tv':
        # BEZPEČNÉ HLEDÁNÍ SOUBORŮ (stejné jako v list_episodes)
        try:
            if hasattr(ws_logic, 'get_season_files_bulk'):
                found = ws_logic.get_season_files_bulk(token, [clean_t, ot], int(s))
            else:
                # Fallback, kdyby ws_logic nebyl aktualizovaný
                for tit in [clean_t, ot]:
                    if tit: found.extend(ws_logic.search_webshare_bulk(f"{tit} s{str(s).zfill(2)}", token, 150))
            
            # Filtrace pro konkrétní epizodu
            valid = [f for f in found if ws_logic.is_valid_file(f.findtext("name"), [clean_t, ot], 'tv', season=s, episode=e)]
        except Exception as ex:
            log_debug(f"resolve_content error: {ex}")
    else:
        for q in titles: found.extend(ws_logic.search_webshare_bulk(q, token, 40))
        try:
            det = tmdb_handler.get_details(tid, 'movie', k)
            year = det.get('release_date', '')[:4]
        except: year = None
        valid = [f for f in found if ws_logic.is_valid_file(f.findtext("name"), titles, 'movie', year=year)]
    
    # Předáme nalezené soubory přehrávači
    select_and_play_file(valid, display_title, ep_uid, media_type, poster)

    token, k = check_prerequisites()
    
    # === DŮLEŽITÉ PRO VZHLED PANELU ===
    xbmcplugin.setContent(HANDLE, 'episodes')
    # ==================================
    
    try:
        eps = tmdb_handler.get_season_episodes(tid, s, k)
    except Exception as e:
        log_debug(f"Error getting TMDB episodes: {e}")
        eps = []

    if not eps:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    
    # BEZPEČNÉ NAČTENÍ SOUBORŮ S FALLBACKEM
    all_files = []
    try:
        # Zkusíme novou optimalizovanou funkci, pokud existuje
        if hasattr(ws_logic, 'get_season_files_bulk'):
            all_files = ws_logic.get_season_files_bulk(token, [clean_t, ot], int(s))
        else:
            # Fallback na starou metodu, pokud ws_logic nebyl aktualizován
            log_debug("get_season_files_bulk not found in ws_logic, using legacy search")
            for tit in [clean_t, ot]:
                if tit:
                    all_files.extend(ws_logic.search_webshare_bulk(f"{tit} s{str(s).zfill(2)}", token, 150))
    except Exception as e:
        log_debug(f"Error fetching files for season: {e}")
        # Nechceme crashnout, zobrazíme aspoň epizody bez linků (budou šedé)
    
    for e in eps:
        ep_uid = f"{tid}_S{s}E{e['episode']}"
        best_lang = ""
        has_f = False
        curr_p = 0
        prio = {'CZ':3, 'CZ TIT':2, 'SK':1.5, 'EN':1}
        
        # Filtrujeme z velkého balíku jen soubory pro tuto konkrétní epizodu
        for f in all_files:
            fn = f.findtext("name")
            try:
                if ws_logic.is_valid_file(fn, [clean_t, ot], 'tv', season=s, episode=e['episode']):
                    has_f = True
                    l = ws_logic.detect_lang_code(fn)
                    p = prio.get(l, 0.5)
                    if p > curr_p:
                        curr_p = p
                        best_lang = l
            except: pass
        
        st = ws_logic.get_watched_status(ep_uid)
        prog = ""
        overlay = None
        if st:
            if st.get('status') == 'watched':
                prog = " [COLOR gray]Zhlédnuto[/COLOR]"
                overlay = ICONS['OVERLAY_WATCHED']
            elif st.get('status') == 'resume':
                prog = f" [COLOR gray]({int(st.get('percentage'))}%)[/COLOR]"
                overlay = ICONS['OVERLAY_RESUME']
        
        lang_str = ""
        if has_f and best_lang:
            l_color = ws_logic.get_lang_color(best_lang)
            lang_str = f" [B][COLOR {l_color}]{best_lang}[/COLOR][/B]"
        label = f"{e['episode']}. {e['name']}{lang_str}{prog}"
        art = {'thumb': e['thumb'], 'icon': overlay if overlay else (e['thumb'] or ICONS['DEF_VIDEO'])}
        info = {
            'title': e['name'], 
            'plot': e.get('overview', ''), 
            'mediatype': 'episode', 
            'season': int(s), 
            'episode': int(e['episode'])
        }
        
        if has_f:
            create_list_item(label, build_url({'mode':'resolve_content','media_type':'tv','id':tid,'s':s,'e':e['episode'],'t':t,'ot':ot,'en':e['name']}), art, info, is_playable=True)
        else:
            create_list_item(f"[COLOR gray]{label} (Nedostupné)[/COLOR]", build_url({'mode':'ignore'}), art, info)
    
    xbmcplugin.endOfDirectory(HANDLE)

def mark_season_watched(tid, s, t):
    """Označí všechny epizody v sérii jako zhlédnuté"""
    pd = xbmcgui.DialogProgress()
    pd.create('Zpracovávám', 'Načítám epizody...')
    
    token, k = check_prerequisites(silent=True)
    try:
        eps = tmdb_handler.get_season_episodes(tid, s, k)
        total = len(eps)
        for idx, e in enumerate(eps):
            if pd.iscanceled(): break
            pd.update(int((idx / total) * 100), f"Značím: {e.get('name', 'Epizoda')}")
            
            uid = f"{tid}_S{s}E{e['episode']}"
            # Simulujeme uložení stavu (status=watched, percentage=100)
            ws_logic.save_playback_status(uid, 'tv', e.get('name'), 0, 0, 'manual_mark', 'manual', year=None, poster=None)
            
            # Musíme ručně přepsat na 100% a watched, protože save_playback_status počítá %
            # Ale ws_logic.save_playback_status to dělá takto: 'status': 'watched' if pct>90
            # Takže stačí zavolat save s time=total_time
            ws_logic.save_playback_status(uid, 'tv', t, 1000, 1000, 'manual', 'manual')
            
    except Exception as e:
        log_debug(f"mark_season_watched error: {e}")
    
    pd.close()
    xbmcgui.Dialog().notification('Hotovo', f'Série {s} označena jako zhlédnutá')
    xbmc.executebuiltin('Container.Refresh') # Obnoví seznam, aby se ukázaly "fajfky"

def play_direct(ident, title, uid, resume, mt, t_val, ident_val, fn_val, year=None, poster=None):
    token, _ = check_prerequisites(silent=True)
    link = ws_logic.get_link(ident, token)
    
    if link:
        data = {"id": uid, "type": mt, "title": t_val, "ident": ident_val, "fname": fn_val, "year": year, "poster": poster}
        CACHE_WINDOW.setProperty('ws_monitor_data', json.dumps(data))
        li = xbmcgui.ListItem(path=link)
        set_video_info_tag(li, {'title': title})
        if float(resume or 0) > 0: li.setProperties({'StartOffset': str(resume)})
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def search_all():
    kb = xbmc.Keyboard('', 'Hledat vše')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _perform_search(kb.getText(), 'all')

def search_movies():
    kb = xbmc.Keyboard('', 'Hledat filmy')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _perform_search(kb.getText(), 'movie')

def search_tv():
    kb = xbmc.Keyboard('', 'Hledat seriály')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _perform_search(kb.getText(), 'tv')

def _perform_search(query, filter_type):
    # 1. Vytvoření Progress Dialogu
    pd = xbmcgui.DialogProgress()
    pd.create('Vyhledávání', f'Hledám: {query}')
    
    ws_logic.add_to_search_history(query)
    token, k = check_prerequisites()
    
    if token:
        # Aktualizace logu
        pd.update(5, 'Kontaktuji TMDb...')
        
        mode = 'movie' if filter_type == 'movie' else 'tv' if filter_type == 'tv' else 'multi'
        
        # Získání výsledků z TMDB
        res = tmdb_handler.search(query, k, search_type=mode)
        
        # Kontrola, zda uživatel nezrušil dialog během hledání na TMDB
        if pd.iscanceled():
            pd.close()
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        final = [item for item in res if filter_type == 'all' or item.get('type') == filter_type]
        
        if not final:
            pd.close()
            xbmcgui.Dialog().notification('Info', 'Nebylo nic nalezeno', xbmcgui.NOTIFICATION_INFO)
        else:
            # 2. Předání dialogu do render funkce, kde proběhne iterace přes Webshare
            render_content_list(final, token, k, progress_bar=pd)
            
        pd.close()
    else:
        pd.close()
        log_debug("_perform_search() missing token")
    
    xbmcplugin.endOfDirectory(HANDLE)

def history_search():
    h = ws_logic.load_history('search_history.json')
    if isinstance(h, list):
        for q in h: create_list_item(q, build_url({'mode':'search_query', 'query':q}), {'icon': ICONS['SEARCH']})
    xbmcplugin.endOfDirectory(HANDLE)

def search_query(q):
    _perform_search(q, 'all')

def mark_ep_watched(uid, t):
    """Označí jednu epizodu jako zhlédnutou"""
    # 100% zhlédnuto, celkový čas např. 1000s, čas přehrání 1000s
    ws_logic.save_playback_status(uid, 'tv', t, 1000, 1000, 'manual', 'manual')
    xbmcgui.Dialog().notification('Webshare', 'Označeno jako zhlédnuté')
    xbmc.executebuiltin('Container.Refresh')

def mark_ep_unwatched(uid):
    """Odstraní status zhlédnutí pro epizodu"""
    # Načteme celou historii, smažeme klíč a uložíme zpět
    w = ws_logic._json_file('watched.json')
    if w and uid in w:
        del w[uid]
        ws_logic._json_file('watched.json', w)
        xbmcgui.Dialog().notification('Webshare', 'Odoznačeno')
        xbmc.executebuiltin('Container.Refresh')

def delete_local_db():
    """Smaže lokální cache"""
    if ws_logic.clear_local_db():
        xbmcgui.Dialog().notification('Databáze', 'Lokální cache byla vymazána')
    else:
        xbmcgui.Dialog().notification('Databáze', 'Cache je prázdná nebo nebyla nalezena')

# ROUTER
mode = ARGS.get('mode', [None])[0]
p = {k: ARGS[k][0] for k in ARGS}

if mode is None:
    main_menu()
elif mode == 'settings':
    ADDON.openSettings()
elif mode == 'show_account_info':
    show_account_info()
elif mode == 'run_speed_test':
    run_speed_test()
elif mode == 'clear_history':
    ws_logic.clear_search_history()
elif mode == 'clear_watched_history':
    ws_logic.clear_watched_history()
elif mode == 'search_all':
    search_all()
elif mode == 'search_movies':
    search_movies()
elif mode == 'search_tv':
    search_tv()
elif mode == 'movies_menu':
    movies_menu()
elif mode == 'tv_menu':
    tv_menu()
elif mode == 'years_menu':
    years_menu(p.get('media_type', 'movie'))
elif mode == 'genres_menu':
    genres_menu(p.get('media_type', 'movie'))
elif mode == 'history_menu':
    history_menu()
elif mode == 'list_tmdb':
    list_tmdb(p['cat'], p.get('tmdb_page', '1'))
elif mode == 'list_discover':
    list_discover(p.get('type'), p.get('media_type'), p.get('tmdb_page', '1'), p.get('year'), p.get('genre_id'))
elif mode == 'list_history':
    list_history(p.get('history_filter', 'resume'))
elif mode == 'search_query':
    search_query(p['query'])
elif mode == 'history_search':
    history_search()
elif mode == 'resolve_content':
    resolve_content(
        p['media_type'],
        p['id'],
        p['t'],
        p.get('ot', ''),
        s=p.get('s'),
        e=p.get('e'),
        en=p.get('en'),
        poster=p.get('poster')
    )
elif mode == 'list_seasons':
    list_seasons(p['id'], p['t'], p.get('ot', ''))
elif mode == 'list_episodes':
    list_episodes(p['id'], p['s'], p['t'], p.get('ot', ''))
elif mode == 'mark_season_watched':
    mark_season_watched(p['id'], p['s'], p['t'])
elif mode == 'mark_ep_watched':
    mark_ep_watched(p['uid'], p.get('t', 'Epizoda'))
elif mode == 'mark_ep_unwatched':
    mark_ep_unwatched(p['uid'])
elif mode == 'delete_local_db':
    delete_local_db()