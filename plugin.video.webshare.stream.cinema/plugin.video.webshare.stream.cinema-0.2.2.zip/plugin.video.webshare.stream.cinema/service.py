import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import time
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import ws_logic

class MyMonitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

class MyPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.tracking = False
        self.data = {}
        self.last_known_time = 0
        self.last_known_total = 0

    def onPlayBackStopped(self):
        self._save_progress(finished=False)

    def onPlayBackEnded(self):
        self._save_progress(finished=True)
    
    def check_playback(self):
        if self.isPlayingVideo():
            # Pokud už sledujeme, jen aktualizujeme čas
            if self.tracking:
                try:
                    t = self.getTime()
                    tt = self.getTotalTime()
                    if t > 0: self.last_known_time = t
                    if tt > 0: self.last_known_total = tt
                except: pass
            
            # Pokud nesledujeme, zkusíme načíst data z globální paměti (od main.py)
            else:
                try:
                    # Čtení z globálního okna (nejspolehlivější metoda)
                    raw_data = xbmcgui.Window(10000).getProperty('ws_monitor_data')
                    
                    if raw_data:
                        info = json.loads(raw_data)
                        # Pokud ID sedí k tomu, co jsme už uložili, nezačínáme znovu (pokud se jen seekovalo)
                        # Ale tady chceme začít sledovat
                        
                        self.tracking = True
                        self.data = info
                        self.last_known_time = 0
                        self.last_known_total = 0
                        
                        # Vymažeme data z okna, aby se nenačetla znovu omylem
                        xbmcgui.Window(10000).clearProperty('ws_monitor_data')
                        
                        xbmcgui.Dialog().notification("Webshare", f"Sleduji: {self.data['title']}", xbmcgui.NOTIFICATION_INFO, 2000)
                except:
                    pass
        
        elif self.tracking:
            self._save_progress(finished=False)

    def _save_progress(self, finished=False):
        if not self.tracking or not self.data.get('id'):
            self.reset_tracking()
            return
            
        try:
            time_pos = self.last_known_time
            total_time = self.last_known_total
            
            if finished:
                if total_time <= 0: total_time = self.getTotalTime()
                time_pos = total_time 

            pct = 0
            if total_time > 0:
                pct = (time_pos / total_time) * 100
            
            msg = f"Uloženo: {int(pct)}%"
            if finished or pct > 90: msg = "Zhlédnuto (100%)"
            elif pct < 1: msg = "" # Ignorovat start

            if msg: xbmcgui.Dialog().notification("Webshare Historie", msg, xbmcgui.NOTIFICATION_INFO, 3000)

            if total_time > 0:
                ws_logic.save_playback_status(
                    self.data['id'], self.data['type'], self.data['title'],
                    time_pos, total_time, self.data['ident'], self.data['fname']
                )
        except: pass
        self.reset_tracking()

    def reset_tracking(self):
        self.tracking = False
        self.data = {}
        self.last_known_time = 0
        self.last_known_total = 0

if __name__ == '__main__':
    monitor = MyMonitor()
    player = MyPlayer()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1): break
        player.check_playback()