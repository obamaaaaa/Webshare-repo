import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
import os
import urllib.parse
import re
import concurrent.futures

# Import logiky
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import ws_logic # type: ignore

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_URL = "plugin://" + ADDON_ID + "/"

# Cesta k ikonám (pro overlay)
ADDON_PATH = ADDON.getAddonInfo('path')
ICON_WATCHED = os.path.join(ADDON_PATH, 'resources', 'media', 'watched.png')
ICON_RESUME = os.path.join(ADDON_PATH, 'resources', 'media', 'resume.png')

# Cesty k ikonám kvality
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')
ICON_4K = os.path.join(MEDIA_PATH, '4k.png')
ICON_1080 = os.path.join(MEDIA_PATH, '1080p.png')
ICON_720 = os.path.join(MEDIA_PATH, '720p.png')
ICON_SD = os.path.join(MEDIA_PATH, 'sd.png')
ICON_DEFAULT_VIDEO = 'DefaultVideo.png'

class WSListWindow(xbmcgui.WindowXML):
    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback=0, **kwargs):
        self.category = kwargs.get('category')
        self.page = int(kwargs.get('page', 1))
        self.token = kwargs.get('token')
        self.tmdb_key = kwargs.get('tmdb_key')
        self.list_items = []
        self.listing_control = None

    def onInit(self):
        # DŮLEŽITÉ: Počkáme, až zmizí předchozí dialogy (Busy spinner) a okno se inicializuje
        xbmc.sleep(500)
        
        try:
            self.listing_control = self.getControl(50)
            self.setProperty('Title', f"Webshare: {self.category.replace('_', ' ').upper()}")
            # Načteme data jen pokud je seznam prázdný
            if not self.list_items:
                self.load_data()
        except Exception as e:
            xbmcgui.Dialog().notification("Webshare GUI Chyba", str(e), xbmcgui.NOTIFICATION_ERROR)

    def _get_status_label_internal(self, item):
        # Interní verze funkce z main.py pro zjištění jazyka a dostupnosti
        t = item['title']
        ot = item['original_title']
        media_type = item['type']
        
        titles = [t]
        if ot != t: titles.append(ot)
        if ":" in t: titles.append(t.split(":")[0].strip())
        
        qs = ws_logic.generate_search_queries(titles)
        
        found_langs = set()
        has_files = False
        
        item_year = None
        if 'year' in item and item['year']:
            if str(item['year']).isdigit(): item_year = int(item['year'])
            elif '-' in str(item['year']): item_year = int(str(item['year']).split('-')[0])

        # Zkusíme jen pár dotazů pro rychlost v GUI
        for q in qs[:3]: 
            if "CZ DAB" in found_langs: break
            res = ws_logic.search_webshare_bulk(q, self.token, limit=5)
            if res:
                for r in res:
                    name = r.findtext("name")
                    is_valid = False
                    if media_type == 'movie':
                        is_valid = ws_logic.is_valid_movie_file(name, titles, year=item_year)
                    else:
                        norm_name = ws_logic.normalize_title(name)
                        for tit in titles:
                            if ws_logic.normalize_title(tit) in norm_name: is_valid = True; break
                    
                    if is_valid:
                        has_files = True
                        l = ws_logic.detect_lang_label(name, titles, orig_title=ot)
                        found_langs.add(l)
        
        lang_label = "EN"
        if "CZ DAB" in found_langs: lang_label = "CZ"
        elif "CZ TIT" in found_langs: lang_label = "CZ titulky"
        
        return has_files, lang_label

    def _process_single_item(self, item):
        try:
            # 1. Získání detailů z TMDB
            det = ws_logic.tmdb_get_details(item['id'], item['type'], self.tmdb_key)
            item.update(det)
            
            # 2. Kontrola dostupnosti a jazyka (Webshare)
            is_available, lang_label = self._get_status_label_internal(item)
            
            # 3. Kontrola historie (Status a Procenta)
            uid = str(item['id'])
            if item['type'] == 'tv':
                 uid = f"{item['id']}_S{item.get('season_number',1)}E{item.get('episode_number',1)}" # Zjednodušeno
                 
            status_info = ws_logic.get_watched_status(uid) 
            
            series_progress_str = ""
            is_watched = False
            pct = 0
            
            if item['type'] == 'tv':
                ep_count = item.get('episodes_count', 0)
                pct, is_started = ws_logic.get_series_progress(item['id'], ep_count)
                if pct >= 100:
                    is_watched = True
                    series_progress_str = " (100%)"
                elif is_started:
                    series_progress_str = f" ({pct}%)"
            else:
                if status_info:
                    pct = status_info.get('percentage', 0)
                    if status_info.get('status') == 'watched':
                        is_watched = True
                        series_progress_str = " (Zhlédnuto)"
                    else:
                        series_progress_str = f" ({int(pct)}%)"

            # 4. Příprava dat pro ListItem
            year_str = f" ({item['year']})" if item.get('year') else ""
            lang_str = f" ({lang_label})" if is_available else " (Nedostupný)"
            
            final_label = f"{item['title']}{year_str}{lang_str}{series_progress_str}"
            if not is_available:
                final_label = f"[COLOR gray]{final_label}[/COLOR]"
            
            # Metadata strings
            cast_str = ", ".join(item.get('cast', []))
            genres_str = ", ".join(item.get('genres', []))
            
            # Výpočet procentuálního hodnocení
            rating_val = item.get('rating', 0)
            rating_pct = f"{rating_val * 10:.1f}%" if rating_val else "0.0%"

            # Vracíme slovník s hotovými daty
            return {
                'label': final_label,
                'poster': item.get('poster', ''),
                'fanart': item.get('fanart', ''),
                'is_watched': is_watched,
                'pct': pct,
                'title': item['title'],
                'original_title': item.get('original_title', ''),
                'release_date': str(item.get('release_date', '')),
                'studio': str(item.get('studio', '')),
                'budget': str(item.get('budget', 'N/A')),
                'revenue': str(item.get('revenue', 'N/A')),
                'rating': str(item.get('rating', '0.0')),
                'rating_pct': rating_pct, # Nová property
                'votes': str(item.get('votes', '0')),
                'director': str(item.get('director', '')),
                'tagline': str(item.get('tagline', '')),
                'cast': cast_str,
                'genres': genres_str,
                'plot': item.get('plot', ''),
                'tmdb_id': str(item['id']),
                'type': item['type'],
                'year': str(item.get('year', '')),
                'duration': str(item.get('duration', 0))
            }
        except Exception:
            return None

    def load_data(self):
        pd = xbmcgui.DialogProgress()
        pd.create("Načítání", "Stahuji data z TMDB...")
        
        try:
            # Použijeme logiku z ws_logic pro získání dat
            if 'popular' in self.category:
                mt = 'movie' if 'movie' in self.category else 'tv'
                results = ws_logic.tmdb_get_popular(self.tmdb_key, mt, 'popular', page=self.page)
            elif 'now' in self.category:
                results = ws_logic.tmdb_get_popular(self.tmdb_key, 'movie', 'now_playing', page=self.page)
            elif 'new' in self.category:
                results = ws_logic.tmdb_get_popular(self.tmdb_key, 'tv', 'on_the_air', page=self.page)
            else:
                results = []

            self.list_items = []
            
            processed_data = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                futures = {executor.submit(self._process_single_item, item): item for item in results}
                total = len(results)
                done_count = 0
                
                for future in concurrent.futures.as_completed(futures):
                    if pd.iscanceled(): break
                    done_count += 1
                    pd.update(int((done_count/total)*100), f"Zpracování: {done_count}/{total}")
                    
                    data = future.result()
                    if data:
                        processed_data.append(data)

            # Sort by original order (optional, here just append)
            # To keep order, we would need to map futures to index.
            
            for data in processed_data:
                li = xbmcgui.ListItem(data['label'])
                li.setArt({'poster': data['poster'], 'fanart': data['fanart']})
                
                li.setInfo('video', {'plot': data['plot'], 'title': data['title']})
                
                # Properties
                li.setProperty('budget', data['budget'])
                li.setProperty('revenue', data['revenue'])
                li.setProperty('studio', data['studio'])
                li.setProperty('tagline', data['tagline'])
                li.setProperty('release_date', data['release_date'])
                li.setProperty('rating', data['rating'])
                li.setProperty('rating_pct', data['rating_pct']) # Procenta
                li.setProperty('votes', data['votes'])
                li.setProperty('director', data['director'])
                li.setProperty('cast', data['cast'])
                li.setProperty('genres', data['genres'])
                li.setProperty('plot', data['plot'])

                # Overlay
                if data['is_watched']:
                    li.setProperty('Overlay', ICON_WATCHED)
                elif data['pct'] > 0:
                    li.setProperty('Overlay', ICON_RESUME)
                
                # Data pro onClick
                li.setProperty('tmdb_id', data['tmdb_id'])
                li.setProperty('type', data['type'])
                li.setProperty('title_val', data['title'])
                li.setProperty('original_title', data['original_title'])
                li.setProperty('poster_url', data['poster'])
                li.setProperty('year', data['year'])
                li.setProperty('duration', data['duration'])
                
                li.setArt({'icon': ICON_DEFAULT_VIDEO})

                self.listing_control.addItem(li)
                self.list_items.append(li)
                
        except Exception as e:
            xbmcgui.Dialog().ok("Chyba", str(e))
        
        pd.close()
        try: self.setFocus(self.listing_control)
        except: pass

    def onClick(self, controlId):
        if controlId == 50:
            item = self.listing_control.getSelectedItem()
            if not item: return

            tmdb_id = item.getProperty('tmdb_id')
            title = item.getProperty('title_val')
            orig_title = item.getProperty('original_title')
            m_type = item.getProperty('type')
            year_val = item.getProperty('year')
            duration_val = item.getProperty('duration')
            poster = item.getProperty('poster_url')
            
            if m_type == 'movie':
                self.play_movie_direct(tmdb_id, title, orig_title, year_val, duration_val)
            elif m_type == 'tv':
                self.close()
                params = {
                    'mode': 'list_seasons',
                    'id': tmdb_id,
                    't': title,
                    'ot': orig_title,
                    'poster': poster
                }
                url = ADDON_URL + "?" + urllib.parse.urlencode(params)
                xbmc.executebuiltin(f'RunPlugin({url})')

    def play_movie_direct(self, tmdb_id, t, ot, year, duration):
        # 1. Resume check
        last_ident, last_fname, resume_time = ws_logic.get_last_played_file(tmdb_id)
        if last_ident:
            if xbmcgui.Dialog().yesno("Pokračovat?", f"Chcete přehrát naposledy zvolený soubor?\n{last_fname}"):
                self.execute_play(last_ident, t, tmdb_id, 'movie', t, last_ident, last_fname, resume_time)
                return

        # 2. Search
        pd = xbmcgui.DialogProgress()
        pd.create("Hledám streamy", f"Hledám: {t}...")
        
        titles = [t]
        if ot != t: titles.append(ot)
        qs = ws_logic.generate_search_queries(titles)
        
        found = {}
        for q in qs:
            if pd.iscanceled(): break
            for f in ws_logic.search_webshare_bulk(q, self.token): 
                found[f.findtext("ident")] = f
        
        pd.close()
        if not found:
            xbmcgui.Dialog().notification("Webshare", "Žádné streamy nenalezeny", xbmcgui.NOTIFICATION_INFO)
            return

        files = list({'node':v, 'name':v.findtext("name"), 'size':v.findtext("size")} 
                     for v in found.values() 
                     if ws_logic.is_valid_movie_file(v.findtext("name"), titles, year=year))
        
        if not files:
            xbmcgui.Dialog().notification("Webshare", "Žádné vyhovující soubory", xbmcgui.NOTIFICATION_INFO)
            return

        meta = {'valid_titles': titles, 'duration': int(duration) if duration else 0}
        sorted_files = ws_logic.sort_results(files, meta, sort_by_lang=False)

        # 3. Select
        l_items = []
        for f in sorted_files:
            n = f['name']; s = f['size']
            q_key, q_label = ws_logic.detect_quality_label(n)
            l = ws_logic.detect_lang_label(n, meta['valid_titles'], orig_title=ot)
            sz = ws_logic.format_size(s)
            br = ws_logic.calculate_bitrate_str(s, meta['duration'])
            
            c_q = "red" if "4K" in q_label else ("lime" if "1080p" in q_label else "yellow")
            c_l = "gold" if "CZ" in l else "white"
            
            li = xbmcgui.ListItem(f"[COLOR {c_q}]{q_label}[/COLOR] | [COLOR {c_l}]{l}[/COLOR] | {sz} | {n} | {br}")
            
            icon_path = ICON_DEFAULT_VIDEO
            if q_key == "4k" and os.path.exists(os.path.join(MEDIA_PATH, '4k.png')): icon_path = os.path.join(MEDIA_PATH, '4k.png')
            elif q_key == "1080p" and os.path.exists(os.path.join(MEDIA_PATH, '1080p.png')): icon_path = os.path.join(MEDIA_PATH, '1080p.png')
            elif q_key == "720p" and os.path.exists(os.path.join(MEDIA_PATH, '720p.png')): icon_path = os.path.join(MEDIA_PATH, '720p.png')
            elif q_key == "sd" and os.path.exists(os.path.join(MEDIA_PATH, 'sd.png')): icon_path = os.path.join(MEDIA_PATH, 'sd.png')
            
            li.setArt({'icon': icon_path})
            l_items.append(li)

        ret = xbmcgui.Dialog().select(t, l_items)
        if ret > -1:
            selected = sorted_files[ret]
            ident = selected['node'].findtext("ident")
            fname = selected['name']
            
            # Uložení stavu watched hned po výběru
            ws_logic.save_playback_status(str(tmdb_id), 'movie', t, 0, 0, ident, fname)
            
            self.execute_play(ident, t, tmdb_id, 'movie', t, ident, fname)

    def execute_play(self, ident, label, ws_id, ws_type, ws_title, ws_ident, ws_fname, resume_time=0):
        link = ws_logic.get_link(ident, self.token)
        if link:
            li = xbmcgui.ListItem(path=link)
            li.setInfo('video', {'title': label})
            
            if resume_time and float(resume_time) > 0:
                 li.setProperties({'StartOffset': str(resume_time)})

            li.setProperties({
                'ws_id': str(ws_id),
                'ws_type': ws_type,
                'ws_title': ws_title,
                'ws_ident': ws_ident,
                'ws_fname': ws_fname
            })
            
            xbmc.Player().play(link, li)
        else:
            xbmcgui.Dialog().notification("Chyba", "Nepodařilo se získat link", xbmcgui.NOTIFICATION_ERROR)

    def onAction(self, action):
        if action.getId() in [92, 10]:
            self.close()

def open_gui(cat, token, key):
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    window = WSListWindow('ws_list.xml', path, 'Default', category=cat, token=token, tmdb_key=key)
    window.doModal()
    del window