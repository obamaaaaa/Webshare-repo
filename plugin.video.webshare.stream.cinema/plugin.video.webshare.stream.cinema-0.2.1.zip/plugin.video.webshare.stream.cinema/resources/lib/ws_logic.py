import requests
import xml.etree.ElementTree as ET
import hashlib
import re
import json
import os
import time
import datetime
import socket
import unicodedata
import xbmc
import xbmcvfs
import xbmcaddon

# IPv4 HACK
orig_getaddrinfo = socket.getaddrinfo
def getaddrinfo_ipv4(host, port, family=0, type=0, proto=0, flags=0):
    return orig_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
socket.getaddrinfo = getaddrinfo_ipv4

VIDEO_EXTS = ('.avi', '.mp4', '.mkv', '.mpg', '.mpeg', '.mov', '.wmv', '.flv', '.webm')

session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=50, pool_maxsize=50)
session.mount('https://', adapter)
session.mount('http://', adapter)

TIMEOUT = (3.05, 10)

CACHE_FILE = 'local_db.json'
CACHE_EXPIRATION = 72 * 60 * 60  # 72 hodin v sekundách

def log_debug(msg):
    """Zapíše debug zprávu do Kodi logu"""
    xbmc.log(f"[Webshare Stream Cinema] [ws_logic.py]: {msg}", xbmc.LOGINFO)

def normalize_title(text):
    """
    Normalizuje text pro porovnání (lowercase, bez diakritiky, jen alfanumerické znaky)
    Args: text='Příliš žluťoučký kůň' -> Returns: 'prilis zlutoucky kun'
    """
    if not text:
        return ""
    text = re.sub(r'^\[.*?\]\s*', '', text)
    text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    result = re.sub(r'\s+', ' ', text).strip()
    return result

def md5_crypt(password, salt, magic='$1$'):
    """
    MD5 crypt pro Webshare API
    Args: password='heslo', salt='abcd1234', magic='$1$'
    """
    if isinstance(password, str): password = password.encode('utf-8')
    if isinstance(salt, str): salt = salt.encode('utf-8')
    if isinstance(magic, str): magic = magic.encode('utf-8')
    m = hashlib.md5(); m.update(password + magic + salt)
    a = hashlib.md5(password + salt + password).digest()
    for i in range(len(password), 0, -16): m.update(a[:min(16, i)])
    i = len(password)
    while i:
        if i & 1: m.update(b'\x00')
        else: m.update(password[0:1])
        i >>= 1
    final = m.digest()
    for i in range(1000):
        m2 = hashlib.md5()
        if i & 1: m2.update(password)
        else: m2.update(final)
        if i % 3: m2.update(salt)
        if i % 7: m2.update(password)
        if i & 1: m2.update(final)
        else: m2.update(password)
        final = m2.digest()
    itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    def to64(v, n):
        ret = ""
        while n - 1 >= 0: n -= 1; ret += itoa64[v & 0x3f]; v >>= 6
        return ret
    hashed = to64((final[0]<<16)|(final[6]<<8)|final[12], 4) + to64((final[1]<<16)|(final[7]<<8)|final[13], 4) + \
             to64((final[2]<<16)|(final[8]<<8)|final[14], 4) + to64((final[3]<<16)|(final[9]<<8)|final[15], 4) + \
             to64((final[4]<<16)|(final[10]<<8)|final[5], 4) + to64(final[11], 2)
    return magic.decode('utf-8') + salt.decode('utf-8') + '$' + hashed

def login(user, password):
    """
    Přihlášení k Webshare API
    Args: user='username', password='heslo'
    Returns: token nebo None
    """
    log_debug(f"login(user={user})")
    if not user or not password:
        log_debug("login() return: None (missing credentials)")
        return None
    try:
        r = session.post("https://webshare.cz/api/salt/", data={'username_or_email': user}, timeout=TIMEOUT)
        salt = ET.fromstring(r.content).findtext("salt")
        if not salt:
            log_debug("login() return: None (no salt)")
            return None
        enc = hashlib.sha1(md5_crypt(password, salt).encode('utf-8')).hexdigest()
        r = session.post("https://webshare.cz/api/login/", data={'username_or_email': user, 'password': enc, 'keep_logged_in': 1}, timeout=TIMEOUT)
        token = ET.fromstring(r.content).findtext("token")
        return token
    except Exception as e:
        log_debug(f"login() exception: {e}, return: None")
        return None

def search_webshare_bulk(query, token, limit=40):
    """
    Hromadné vyhledávání na Webshare
    Args: query='matrix', token='...', limit=40
    Returns: list XML file elementů
    """
    log_debug(f"search_webshare_bulk(query={query}, limit={limit})")
    try:
        q = normalize_title(query)
        r = session.post("https://webshare.cz/api/search/", 
                         data={'what': q, 'limit': limit, 'sort': 'rating', 'category': 'video', 'wst': token}, 
                         timeout=TIMEOUT)
        results = ET.fromstring(r.content).findall("file")
        log_debug(f"search_webshare_bulk() return: {len(results)} files")
        return results
    except Exception as e:
        log_debug(f"search_webshare_bulk() exception: {e}, return: []")
        return []

def get_link(ident, token):
    """
    Získá přímý link na soubor
    Args: ident='abc123', token='...'
    Returns: URL string nebo None
    """
    try:
        r = session.post("https://webshare.cz/api/file_link/", data={'ident': ident, 'wst': token}, timeout=TIMEOUT)
        link = ET.fromstring(r.content).findtext("link")
        return link
    except Exception as e:
        log_debug(f"get_link() exception: {e}, return: None")
        return None

def get_user_info(token):
    """
    Načte informace o uživateli
    Args: token='...'
    Returns: dict {'username', 'is_vip', 'expire'} nebo None
    """
    try:
        r = session.post("https://webshare.cz/api/user_data/", data={'wst': token}, timeout=TIMEOUT)
        root = ET.fromstring(r.content)
        is_vip = root.findtext("vip") == "1"
        expire_val = root.findtext("vip_until")
        if is_vip and expire_val:
            try:
                v = int(expire_val)
                if v > 1000000000: exp = datetime.datetime.fromtimestamp(v).strftime("%d.%m.%Y")
                else: exp = (datetime.datetime.now() + datetime.timedelta(days=v)).strftime("%d.%m.%Y")
            except: exp = str(expire_val)
        else: exp = "Neaktivní"
        result = {'username': root.findtext("username"), 'is_vip': is_vip, 'expire': exp}
        log_debug(f"get_user_info() return: username={result['username']}, is_vip={is_vip}")
        return result
    except Exception as e:
        log_debug(f"get_user_info() exception: {e}, return: None")
        return None

def is_valid_file(filename, titles, media_type, season=None, episode=None, year=None):
    """
    VYLEPŠENÁ VALIDACE SOUBORU s detailním důvodem zamítnutí.
    
    Args:
        filename: Název souboru k ověření
        titles: Seznam možných názvů (český, originální, anglický)
        media_type: 'movie' nebo 'tv'
        season: Číslo série (pro TV)
        episode: Číslo epizody (pro TV)
        year: Rok vydání (pro filmy)
    
    Returns:
        bool: True pokud je soubor validní, False jinak
        
    Klíčová vylepšení:
    - Soubor MUSÍ začínat názvem (startswith) - eliminuje falešné pozitivní
    - Kontrola sequelů (Movie vs Movie 2)
    - Kontrola "song" v názvu
    - Striktní ověření SxxExx vzoru pro seriály
    """
    if not filename:
        return False
    
    fn = filename.lower()
    
    # Základní kontroly
    if not fn.endswith(VIDEO_EXTS):
        return False
    if "sample" in fn:
        return False
    
    f_norm = normalize_title(fn)

    # === SERIÁLY ===
    if media_type == 'tv':
        if season is None or episode is None:
            return False
        
        s_int = int(season)
        e_int = int(episode)
        
        # 1. Kontrola názvu (MUSÍ ZAČÍNAT)
        title_matched = False
        for t in titles:
            q_norm = normalize_title(t)
            if f_norm.startswith(q_norm):
                # Kontrola hranice slova (aby "Bat" nenašlo "Batman")
                if len(f_norm) == len(q_norm) or f_norm[len(q_norm)] == ' ':
                    title_matched = True
                    break
        
        if not title_matched:
            return False

        # 2. Striktní kontrola SxxExx
        pat = r"(?i)(s0?{s}[ ._-]*e0?{e}|{s}x0?{e})(?!\d)".format(s=s_int, e=e_int)
        if re.search(pat, fn):
            return True
        
        return False

    # === FILMY ===
    elif media_type == 'movie':
        # 1. Kontrola "Song"
        # Pokud ani jeden z názvů filmu neobsahuje "song", ale soubor ano -> zamítnout
        q_has_song = any("song" in normalize_title(t) for t in titles)
        if "song" in f_norm and not q_has_song:
            return False

        # 2. Kontrola, zda to nevypadá jako epizoda
        if re.search(r's\d{2}[._-]*e\d{2}', fn) or re.search(r'\b\d{1,2}x\d{2}\b', fn):
            return False

        # 3. Kontrola Roku (+/- 1 rok)
        if year:
            y_match = re.findall(r'\b(19\d{2}|20\d{2})\b', fn)
            if y_match:
                if not any(int(y) in [int(year), int(year)-1, int(year)+1] for y in y_match):
                    return False

        # 4. Kontrola Názvu (STARTS WITH + SEQUEL CHECK)
        title_matched = False
        
        for t in titles:
            t_norm = normalize_title(t)
            
            # Musí začínat názvem
            if not f_norm.startswith(t_norm):
                continue
            
            # Kontrola hranice slova (aby "Bat" nenašlo "Batman")
            if len(f_norm) > len(t_norm) and f_norm[len(t_norm)] != ' ':
                continue
                
            # === SEQUEL CHECK ===
            # Zkontrolujeme, co následuje hned za názvem
            remainder = f_norm[len(t_norm):].strip()
            
            if remainder:
                first_token = remainder.split()[0]
                
                # Pokud je hned za názvem číslo
                if first_token.isdigit():
                    num_val = int(first_token)
                    
                    # Je to rok? OK.
                    if 1900 < num_val < 2100:
                        pass
                    # Je to rozlišení? (např. 1080, 720, 2160). OK.
                    elif num_val in [1080, 720, 2160, 480, 4]:
                        pass
                    else:
                        # Je to jiné číslo (např. '2', '3') = sequel
                        # Pokud jsme hledali "Movie" a soubor je "Movie 2", zamítneme
                        continue

            title_matched = True
            break
        
        if not title_matched:
            return False

        return True

    return False

def detect_quality_label(name):
    """
    Detekuje kvalitu videa z názvu
    Args: name='movie.2020.1080p.mkv'
    Returns: ('1080p', '1080p')
    """
    n = name.lower()
    if "4k" in n or "2160" in n:
        return "4k", "4K UHD"
    if "1080" in n:
        return "1080p", "1080p"
    if "720" in n:
        return "720p", "720p"
    return "sd", "SD"

def detect_lang_code(n):
    """
    Detekuje jazyk souboru z názvu
    Args: n='movie.2020.cz.mkv' -> Returns: 'CZ'
    """
    n = n.lower()
    
    # 1. Priorita: CZ Titulky
    if re.search(r'cz[ ._-]?(tit|sub)', n):
        return "CZ TIT"

    # 2. Priorita: Slovenština (musí být PŘED obecnou kontrolou 'dab')
    if re.search(r'(?:^|[ ._\-\[])(sk|slo|slovak)(?:$|[ ._\-\]])', n):
        return "SK"

    # 3. Obecná kontrola Češtiny / Dabingu
    if "cz" in n or "dab" in n or "cesky" in n or "česky" in n:
        return "CZ"
    
    # 4. Ostatní jazyky
    langs = {
        'EN': ['en', 'eng', 'english'],
        'FR': ['fr', 'fra', 'fre', 'french'],
        'DE': ['de', 'ger', 'german', 'deutsch'],
        'RU': ['ru', 'rus', 'russian'],
        'PL': ['pl', 'pol', 'polish'],
        'IT': ['it', 'ita', 'italian'],
        'ES': ['es', 'spa', 'spanish'],
        'HU': ['hu', 'hun', 'hungarian'],
        'JP': ['jp', 'jap', 'japanese'],
        'KR': ['kr', 'kor', 'korean'],
        'CN': ['cn', 'zh', 'chi', 'chinese']
    }
    for code, keywords in langs.items():
        for kw in keywords:
            if re.search(r'(?:^|[ ._\-\[])' + kw + r'(?:$|[ ._\-\]])', n):
                return code
    return "EN"

def detect_lang_label(n):
    """Alias pro detect_lang_code"""
    return detect_lang_code(n)

def format_size(s):
    """
    Formátuje velikost souboru
    Args: s='1073741824' -> Returns: '1.00 GB'
    """
    try:
        s = float(s or 0)
        for u in ['B','KB','MB','GB']:
            if s < 1024:
                result = f"{s:.2f} {u}"
                return result
            s /= 1024
    except:
        pass
    return "0 B"

def format_currency(value):
    """
    Formátuje měnu
    Args: value=1000000 -> Returns: '$1.000.000'
    """
    try:
        val = int(value or 0)
        if val == 0:
            return "-"
        result = "${:,.0f}".format(val).replace(",", ".")
        return result
    except:
        return "-"

def format_date_cz(date_str):
    """
    Formátuje datum do CZ formátu
    Args: date_str='2020-12-25' -> Returns: '25.12.2020'
    """
    try:
        parts = str(date_str).split('-')
        if len(parts) == 3:
            result = f"{parts[2]}.{parts[1]}.{parts[0]}"
            return result
    except:
        pass
    return date_str or ""

def generate_episode_queries(titles, s, e):
    """
    Generuje vyhledávací dotazy pro epizody
    Args: titles=['Show'], s=1, e=5 -> Returns: ['show s01e05', 'show 1x05']
    """
    queries = set()
    s_str = str(s).zfill(2); e_str = str(e).zfill(2)
    for t in titles:
        clean = normalize_title(t)
        queries.add(f"{clean} s{s_str}e{e_str}")
        queries.add(f"{clean} {s}x{e_str}")
    result = list(queries)
    return result

def _json_file(filename, data=None):
    """
    Načítá nebo ukládá JSON soubor
    Args: filename='watched.json', data=None (read) nebo data={...} (write)
    Returns: dict při čtení, bool při zápisu
    """
    path = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), filename))
    if data is None:
        if not os.path.exists(path):
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                result = json.load(f)
                return result
        except Exception as e:
            log_debug(f"_json_file() exception: {e}, return: {{}}")
            return {}
    else:
        folder = os.path.dirname(path)
        if not os.path.exists(folder): os.makedirs(folder)
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            log_debug(f"_json_file() exception: {e}, return: False")
            return False

def save_playback_status(uid, mt, title, t, tt, ident, fname, year=None, poster=None):
    """
    Uloží stav přehrávání
    Args: uid='123', mt='movie', title='Movie', t=300, tt=6000, ident='abc', fname='movie.mkv'
    """
    w = _json_file('watched.json')
    if not isinstance(w, dict): w = {}
    pct = (t/tt*100) if tt>0 else 0
    w[str(uid)] = {
        'type': mt, 'title': title, 'percentage': round(pct,1), 
        'status': 'watched' if pct>90 else 'resume', 
        'resume_time': t if pct<90 else 0, 'total_time': tt, 
        'last_ident': ident, 'last_file': fname, 'id': uid, 'unique_id': uid, 
        'date': time.strftime("%Y-%m-%d %H:%M"),
        'year': year, 'poster': poster
    }
    result = _json_file('watched.json', w)
    log_debug(f"save_playback_status() saved: {result}")

def get_watched_status(uid, check_specific_status=None):
    """
    Získá stav přehrávání položky
    Args: uid='123', check_specific_status='watched' nebo None
    Returns: dict nebo None
    """
    w = _json_file('watched.json')
    item = w.get(str(uid))
    if item and check_specific_status:
        if item.get('status') == check_specific_status:
            return item
        return None
    return item

def get_history_items(filter_type=None):
    """
    Získá položky z historie
    Args: filter_type='resume' nebo 'watched' nebo None
    Returns: list slovníků
    """
    w = _json_file('watched.json')
    items = []
    seen_series = set()
    for k, v in w.items():
        if v['type'] == 'movie':
            if filter_type and v.get('status') != filter_type: continue
            items.append(v)
        elif v['type'] == 'tv':
            sid = k.split('_')[0]
            if sid not in seen_series:
                seen_series.add(sid)
                items.append({'id': sid, 'type': 'tv', 'title': v['title'].split(' - ')[0], 'year': v.get('year'), 'poster': v.get('poster'), 'unique_id': sid, 'date': v.get('date', '')})
    result = sorted(items, key=lambda x: x['date'], reverse=True)
    return result

def add_to_search_history(q):
    """
    Přidá dotaz do historie vyhledávání
    Args: q='matrix'
    """
    log_debug(f"add_to_search_history(q={q})")
    if not q: return
    h = _json_file('search_history.json')
    if not isinstance(h, list): h = []
    q_clean = q.strip()
    h = [x for x in h if x.lower() != q_clean.lower()]
    h.insert(0, q_clean)
    result = _json_file('search_history.json', h[:50])
    log_debug(f"add_to_search_history() saved: {result}")

def clear_search_history():
    """Smaže historii vyhledávání"""
    log_debug("clear_search_history()")
    p = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), 'search_history.json'))
    if os.path.exists(p):
        os.remove(p)
        log_debug("clear_search_history() deleted")
    else:
        log_debug("clear_search_history() file not exists")

def clear_watched_history():
    """Smaže historii sledování"""
    log_debug("clear_watched_history()")
    p = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), 'watched.json'))
    if os.path.exists(p):
        os.remove(p)
        log_debug("clear_watched_history() deleted")
    else:
        log_debug("clear_watched_history() file not exists")

def load_history(filename):
    """
    Načte historii ze souboru
    Args: filename='search_history.json'
    """
    log_debug(f"load_history(filename={filename})")
    result = _json_file(filename)
    return result

def get_last_played_file(uid):
    """
    Získá poslední přehrávaný soubor
    Args: uid='123'
    Returns: (ident, filename, resume_time)
    """
    log_debug(f"get_last_played_file(uid={uid})")
    info = get_watched_status(uid)
    if info:
        result = (info.get('last_ident'), info.get('last_file'), info.get('resume_time', 0))
        log_debug(f"get_last_played_file() return: ident={result[0]}, resume={result[2]}")
        return result
    log_debug("get_last_played_file() return: (None, None, 0)")
    return None, None, 0

def measure_download_speed(token, callback):
    """
    Změří rychlost stahování
    Args: token='...', callback=function
    Returns: (avg_speed_mbps, max_speed_mbps) nebo (-2.0, -2.0) při chybě sítě
    """
    log_debug("measure_download_speed()")
    highest_speed = 0.0 
    ident = "4f72gC6392"
    link = get_link(ident, token)
    
    if not link:
        log_debug("measure_download_speed() return: (-2.0, -2.0) - no link")
        return -2.0, -2.0
    
    start = time.time(); downloaded = 0
    try:
        r = session.get(link, stream=True, timeout=10)
    except Exception as e:
        log_debug(f"measure_download_speed() exception: {e}, return: (-2.0, -2.0)")
        return -2.0, -2.0
    
    for chunk in r.iter_content(chunk_size=1024*1024):
        if callback(0, 0, abort_check=True):
            log_debug("measure_download_speed() return: (0.0, 0.0) - aborted")
            return 0.0, 0.0
        downloaded += len(chunk)
        
        elapsed = time.time() - start
        if elapsed > 0:
            current_speed_mbps = (downloaded * 8) / elapsed / 1000000
            if current_speed_mbps > highest_speed:
                highest_speed = current_speed_mbps
            speed_str = f"{current_speed_mbps:.2f} Mbps"
        else:
            current_speed_mbps = 0.0
            speed_str = "0.00 Mbps"
            
        callback(min(int((elapsed/10)*100), 100), round(highest_speed, 2), msg=f"Stahuji: {speed_str}")
        if elapsed > 10.0: break
        
    dur = time.time() - start
    if dur < 0.1:
        log_debug("measure_download_speed() return: (0.0, 0.0) - too short")
        return 0.0, 0.0
    
    final_avg_speed = round((downloaded * 8) / dur / 1000000, 2)
    final_max_speed = round(highest_speed, 2)
    log_debug(f"measure_download_speed() return: ({final_avg_speed}, {final_max_speed})")
    return final_avg_speed, final_max_speed

def get_series_progress_stats(tid):
    """
    Získá počet zhlédnutých epizod seriálu
    Args: tid='12345'
    Returns: int (počet)
    """
    log_debug(f"get_series_progress_stats(tid={tid})")
    w = _json_file('watched.json')
    watched_eps = set()
    prefix = f"{tid}_S"
    for k, v in w.items():
        if k.startswith(prefix) and v.get('status') == 'watched':
            watched_eps.add(k)
    count = len(watched_eps)
    log_debug(f"get_series_progress_stats() return: {count}")
    return count

def get_language_priority(lang_code):
    """
    Získá prioritu jazyka
    Args: lang_code='CZ' -> Returns: 100
    """
    prio = {
        'CZ': 100,
        'CZ TIT': 90,
        'SK': 80,
        'EN': 50
    }
    result = prio.get(lang_code, 10)
    return result

def get_quality_color(quality_key):
    """Získá barvu pro kvalitu videa"""
    colors = {
        '4k': 'red',
        '1080p': 'lime',
        '720p': 'yellow',
        'sd': 'white'
    }
    result = colors.get(quality_key, 'white')
    return result

def get_lang_color(lang_code):
    """Získá barvu pro jazyk"""
    colors = {
        'CZ': 'gold',
        'CZ TIT': 'orange',
        'SK': 'yellow',
        'EN': 'white'
    }
    result = colors.get(lang_code, 'white')
    return result

def format_quality_lang_label(quality_key, quality_label, lang_code):
    """Formátuje label s barevnou kvalitou a jazykem"""
    q_color = get_quality_color(quality_key)
    l_color = get_lang_color(lang_code)
    result = f"[COLOR {q_color}]{quality_label}[/COLOR] | [COLOR {l_color}]{lang_code}[/COLOR]"
    return result

def detect_quality_from_lang_label(lang_label):
    """Detekuje nejvyšší kvalitu z jazyka/kvality label"""
    result = ('1080p', '1080p')
    return result

def get_season_files_bulk(token, titles, season):
    """
    JEDNOTNÁ FUNKCE: Stáhne soubory pro celou sezónu.
    Používá se v list_episodes i resolve_content pro 100% shodu.
    """
    log_debug(f"get_season_files_bulk(titles={titles}, season={season})")
    all_files = []
    # Deduplikace titulů pro hledání
    search_titles = list(dict.fromkeys(titles)) 
    
    for tit in search_titles:
        if tit:
            q = f"{tit} s{str(season).zfill(2)}"
            all_files.extend(search_webshare_bulk(q, token, limit=200))
            
    # Odstraníme duplicity souborů (podle identu)
    seen_idents = set()
    unique_files = []
    for f in all_files:
        ident = f.findtext("ident")
        if ident and ident not in seen_idents:
            seen_idents.add(ident)
            unique_files.append(f)
            
    return unique_files

def get_cached_data(key):
    """Načte data z lokální DB, pokud nejsou starší než 48h"""
    db = _json_file(CACHE_FILE)
    if not db or key not in db:
        return None
    
    entry = db[key]
    saved_time = entry.get('timestamp', 0)
    
    if time.time() - saved_time > CACHE_EXPIRATION:
        log_debug(f"Cache expired for key: {key}")
        del db[key]
        _json_file(CACHE_FILE, db)
        return None
        
    log_debug(f"Cache HIT for key: {key}")
    return entry.get('items', [])

def save_cached_data(key, items):
    """Uloží data do lokální DB s aktuálním časem"""
    db = _json_file(CACHE_FILE)
    if not isinstance(db, dict): db = {}
    
    db[key] = {
        'timestamp': int(time.time()),
        'items': items
    }
    _json_file(CACHE_FILE, db)
    log_debug(f"Cache SAVED for key: {key}")

def clear_local_db():
    """Smaže celou lokální databázi"""
    p = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), CACHE_FILE))
    if os.path.exists(p):
        os.remove(p)
        return True
    return False