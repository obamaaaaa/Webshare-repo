import requests
import urllib.parse
import xbmc

TMDB_BASE = "https://api.themoviedb.org/3"
TMDB_IMG = "https://image.tmdb.org/t/p/w500"
TMDB_BG  = "https://image.tmdb.org/t/p/w1280"
TIMEOUT = (3.05, 10)

GENRES = {
    "Akční": 28, "Dobrodružné": 12, "Animované": 16, "Komedie": 35, 
    "Krimi": 80, "Dokumentární": 99, "Drama": 18, "Rodinné": 10751, 
    "Fantasy": 14, "Historické": 36, "Horor": 27, "Hudební": 10402, 
    "Mysteriózní": 9648, "Romantické": 10749, "Sci-Fi": 878, 
    "TV Film": 10770, "Thriller": 53, "Válečné": 10752, "Western": 37
}

def log_debug(msg):
    """Zapíše debug zprávu do Kodi logu"""
    xbmc.log(f"[Webshare Stream Cinema] [tmdb_handler.py]: {msg}", xbmc.LOGINFO)

def parse_tmdb_list(data, forced_type=None):
    """
    Parsuje TMDb výsledky do standardního formátu
    Args: data={'results': [...]}, forced_type='movie' nebo None
    Returns: list slovníků s klíči id, type, title, year, poster, fanart
    """
    # log_debug(f"parse_tmdb_list(forced_type={forced_type})")
    results = []

    if not data or 'results' not in data:
        log_debug("parse_tmdb_list() return: [] (no data or results)")
        return []
    
    for i in data['results']:
        if 'title' in i:
            mt = 'movie'
            tit = i.get('title')
            orig_tit = i.get('original_title')
        elif 'name' in i:
            mt = 'tv'
            tit = i.get('name')
            orig_tit = i.get('original_name')
        else:
            continue

        if forced_type:
            mt = forced_type

        results.append({
            'id': i['id'],
            'type': mt,
            'title': tit,
            'original_title': orig_tit or tit,
            'year': (i.get('release_date') or i.get('first_air_date') or "")[:4],
            'poster': f"{TMDB_IMG}{i.get('poster_path')}" if i.get('poster_path') else "",
            'fanart': f"{TMDB_BG}{i.get('backdrop_path')}" if i.get('backdrop_path') else "",
        })
    
    # log_debug(f"parse_tmdb_list() return: {len(results)} items")
    return results

def get_popular(key, mt, cat, page=1):
    """
    Získá populární obsah z TMDb
    Args: key='api_key', mt='movie', cat='popular', page=1
    Returns: list položek
    """
    log_debug(f"get_popular(mt={mt}, cat={cat}, page={page})")
    try:
        r = requests.get(f"{TMDB_BASE}/{mt}/{cat}?api_key={key}&language=cs-CZ&page={page}", timeout=TIMEOUT)
        results = parse_tmdb_list(r.json())
        # log_debug(f"get_popular() return: {len(results)} items")
        return results
    except Exception as e:
        log_debug(f"get_popular() exception: {e}, return: []")
        return []

def discover(key, type='movie', params={}, page=1):
    """
    TMDb discover endpoint
    Args: key='api_key', type='movie', params={'year': '2020'}, page=1
    Returns: list položek
    """
    # log_debug(f"discover(type={type}, params={params}, page={page})")
    try:
        url = f"{TMDB_BASE}/discover/{type}?api_key={key}&language=cs-CZ&page={page}"
        for k, v in params.items(): url += f"&{k}={v}"
        r = requests.get(url, timeout=TIMEOUT)
        results = parse_tmdb_list(r.json())
        # log_debug(f"discover() return: {len(results)} items")
        return results
    except Exception as e:
        log_debug(f"discover() exception: {e}, return: []")
        return []

def search(query, key, search_type="multi"):
    """
    Vyhledá obsah na TMDb
    Args: query='matrix', key='api_key', search_type='multi' nebo 'movie' nebo 'tv'
    Returns: list položek
    """
    # log_debug(f"search(query={query}, search_type={search_type})")
    
    if not query:
        log_debug("search() return: [] (empty query)")
        return []
    
    try:
        url = f"{TMDB_BASE}/search/{search_type}?api_key={key}&language=cs-CZ&query={urllib.parse.quote(query)}"
        r = requests.get(url, timeout=TIMEOUT)
        
        log_debug(f"search() TMDb API status: {r.status_code}")
        
        if r.status_code != 200:
            log_debug(f"search() API error, return: []")
            return []
        
        data = r.json()
        total_results = data.get('total_results', 0)
        # log_debug(f"search() TMDb total_results: {total_results}")

        if 'results' not in data:
            log_debug("search() return: [] (no results key)")
            return []
        
        parsed = parse_tmdb_list(data, forced_type=None if search_type == 'multi' else search_type)
        # log_debug(f"search() return: {len(parsed)} items")
        return parsed
    except Exception as e:
        log_debug(f"search() exception: {e}, return: []")
        return []

def get_details(tid, mt, key):
    """
    Získá detaily o filmu/seriálu
    Args: tid=123, mt='movie', key='api_key'
    Returns: dict s detaily (plot, rating, cast, genres, ...)
    """
    # log_debug(f"get_details(tid={tid}, mt={mt})")
    try:
        url = f"{TMDB_BASE}/{mt}/{tid}?api_key={key}&language=cs-CZ&append_to_response=credits"
        r = requests.get(url, timeout=TIMEOUT)
        d = r.json()
        cast = []
        if 'credits' in d and 'cast' in d['credits']:
            cast = [c['name'] for c in d['credits']['cast'][:10]]
            
        studios = [c['name'] for c in d.get('production_companies', [])]
        studio_str = studios[0] if studios else ""

        genres = [g['name'] for g in d.get('genres', [])]

        result = {
            'plot': d.get('overview', ''),
            'rating': d.get('vote_average', 0),
            'episodes_count': d.get('number_of_episodes', 0),
            'seasons_count': d.get('number_of_seasons', 0),
            'duration': d.get('runtime') or (d.get('episode_run_time') or [45])[0],
            'release_date': d.get('release_date') or d.get('first_air_date', ''),
            'poster': f"{TMDB_IMG}{d.get('poster_path')}" if d.get('poster_path') else "",
            'fanart': f"{TMDB_BG}{d.get('backdrop_path')}" if d.get('backdrop_path') else "",
            'budget': d.get('budget', 0),
            'revenue': d.get('revenue', 0),
            'studio': studio_str,
            'cast': cast,
            'genres': genres
        }
        # log_debug(f"get_details() return: dict with {len(cast)} cast, {len(genres)} genres")
        return result
    except Exception as e:
        log_debug(f"get_details() exception: {e}, return: {{}}")
        return {}

def get_season_episodes(tid, s_num, key):
    """
    Získá seznam epizod sezóny
    Args: tid=123, s_num=1, key='api_key'
    Returns: list dict [{'episode': 1, 'name': '...', 'overview': '...', 'thumb': '...'}]
    """
    log_debug(f"get_season_episodes(tid={tid}, s_num={s_num})")
    try:
        url = f"{TMDB_BASE}/tv/{tid}/season/{s_num}?api_key={key}&language=cs-CZ"
        r = requests.get(url, timeout=TIMEOUT)
        episodes = [{'episode': e['episode_number'], 'name': e['name'], 'overview': e['overview'], 
                 'thumb': f"{TMDB_IMG}{e.get('still_path')}" if e.get('still_path') else ""} for e in r.json().get('episodes', [])]
        log_debug(f"get_season_episodes() return: {len(episodes)} episodes")
        return episodes
    except Exception as e:
        log_debug(f"get_season_episodes() exception: {e}, return: []")
        return []

def get_en_title(tid, mt, key):
    """
    Získá anglický název
    Args: tid=123, mt='movie', key='api_key'
    Returns: string nebo None
    """
    #log_debug(f"get_en_title(tid={tid}, mt={mt})")
    try:
        endpoint = 'movie' if mt == 'movie' else 'tv'
        url = f"{TMDB_BASE}/{endpoint}/{tid}?api_key={key}&language=en-US"
        r = requests.get(url, timeout=TIMEOUT)
        title = r.json().get('title') if mt == 'movie' else r.json().get('name')
        # log_debug(f"get_en_title() return: {title if title else 'None'}")
        return title
    except Exception as e:
        log_debug(f"get_en_title() exception: {e}, return: None")
        return None

def smart_pagination_fetch(fetch_func, tmdb_key, start_page, start_index, required_count, hide_unavailable, token, processor_func, media_type=None):
    """
    Jednoduchá paginace - načte požadovaný počet položek
    Args: fetch_func=callable, start_page=1, start_index=0, required_count=20
    Returns: (items, next_page, next_index)
    """
    log_debug(f"smart_pagination_fetch(start_page={start_page}, start_index={start_index}, required_count={required_count})")
    items = fetch_func(page=start_page)
    res = items[start_index:start_index + required_count]
    log_debug(f"smart_pagination_fetch() return: {len(res)} items, next_page={start_page}")
    return res, start_page, start_index + required_count