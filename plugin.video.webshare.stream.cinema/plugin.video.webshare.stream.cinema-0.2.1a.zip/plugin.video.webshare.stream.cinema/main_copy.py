import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import os
import datetime
import concurrent.futures
import re
from collections import Counter

sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import ws_logic
import tmdb_handler

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])
CACHE_WINDOW = xbmcgui.Window(10000)

ADDON_PATH = ADDON.getAddonInfo('path')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

ICONS = {
    'SEARCH': os.path.join(MEDIA_PATH, 'search.png'),
    'FILM': os.path.join(MEDIA_PATH, 'film.png'),
    'HISTORY': os.path.join(MEDIA_PATH, 'history.png'),
    'RESUME': os.path.join(MEDIA_PATH, 'history_resume.png'),
    'WATCHED': os.path.join(MEDIA_PATH, 'history_watched.png'),
    'POPULAR': os.path.join(MEDIA_PATH, 'popular.png'),
    'THEATRE': os.path.join(MEDIA_PATH, 'theatre.png'),
    'CZ': os.path.join(MEDIA_PATH, 'cz.png'),
    'TRANSCRIPT': os.path.join(MEDIA_PATH, 'transcript.png'),
    'CALENDAR': os.path.join(MEDIA_PATH, 'calendar.png'),
    'BOOK': os.path.join(MEDIA_PATH, 'book.png'),
    'OVERLAY_WATCHED': os.path.join(MEDIA_PATH, 'watched.png'),
    'OVERLAY_RESUME': os.path.join(MEDIA_PATH, 'resume.png'),
    '4K': os.path.join(MEDIA_PATH, '4k.png'),
    '1080': os.path.join(MEDIA_PATH, '1080p.png'),
    '720': os.path.join(MEDIA_PATH, '720p.png'),
    'SD': os.path.join(MEDIA_PATH, 'sd.png'),
    'DEF_VIDEO': 'DefaultVideo.png',
    'DEF_FOLDER': 'DefaultFolder.png',
    'SETTINGS': 'DefaultAddonService.png'
}

def log_debug(msg):
    """Zapíše debug zprávu do Kodi logu"""
    xbmc.log(f"[Webshare Stream Cinema] [main.py]: {msg}", xbmc.LOGINFO)

def get_setting(name):
    """Získá nastavení z addonu"""
    return ADDON.getSetting(name)

def build_url(query):
    """
    Sestaví URL pro addon
    Args: query={'mode': 'search', 'query': 'matrix'}
    """
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def set_video_info_tag(li, info):
    """
    Nastaví video info tag pro ListItem
    Args: li=ListItem, info={'title': '...', 'plot': '...', ...}
    """
    try:
        tag = li.getVideoInfoTag()
        if 'title' in info: tag.setTitle(info['title'])
        if 'plot' in info: tag.setPlot(info['plot'])
        if 'year' in info: tag.setYear(int(info['year']))
        if 'rating' in info: tag.setRating(float(info['rating']))
        if 'duration' in info: tag.setDuration(int(info['duration']))
        if 'cast' in info: tag.setCast([xbmc.Actor(name=c) for c in info['cast']])
        if 'genres' in info: tag.setGenres(info['genres'])
    except AttributeError:
        pass 
    li.setInfo('video', info)

def create_list_item(label, path, art=None, info=None, is_folder=True, is_playable=False, context_menu=None):
    """
    Vytvoří a přidá list item do directory
    Args: label='Title', path='plugin://...', art={'icon': '...'}, is_folder=True
    """
    li = xbmcgui.ListItem(label)
    if art:
        if 'icon' not in art or not art['icon']: 
            art['icon'] = ICONS['DEF_FOLDER'] if is_folder else ICONS['DEF_VIDEO']
        if 'thumb' not in art: art['thumb'] = art['icon']
        if 'poster' not in art: art['poster'] = art['icon']
        li.setArt(art)
    if info:
        set_video_info_tag(li, info)
    if is_playable:
        li.setProperty('IsPlayable', 'true')
        is_folder = False
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(HANDLE, path, li, is_folder)

def check_prerequisites(silent=False):
    """
    Kontrola přihlášení a API klíče
    Args: silent=False (ukáže dialogy při chybě)
    Returns: (token, tmdb_key) nebo (None, None)
    """
    log_debug(f"check_prerequisites(silent={silent})")
    user = get_setting('username')
    tmdb_key = get_setting('tmdb_api_key')
    if not tmdb_key:
        if not silent: ADDON.openSettings()
        log_debug("check_prerequisites() return: (None, None) - no tmdb_key")
        return None, None
    token = CACHE_WINDOW.getProperty('ws_token')
    if not token:
        token = ws_logic.login(user, get_setting('password'))
        if not token:
            if not silent: xbmcgui.Dialog().ok('Chyba', 'Chyba přihlášení Webshare.')
            log_debug("check_prerequisites() return: (None, None) - login failed")
            return None, None
        CACHE_WINDOW.setProperty('ws_token', token)
    log_debug("check_prerequisites() return: (token, tmdb_key)")
    return token, tmdb_key

def check_first_run():
    """Kontrola prvního spuštění"""
    log_debug("check_first_run()")
    if get_setting('first_run_done') == 'true':
        log_debug("check_first_run() already done")
        return
    xbmcgui.Dialog().ok("Vítejte", "Webshare Stream Cinema je připraven.")
    ADDON.setSetting('first_run_done', 'true')
    log_debug("check_first_run() first run completed")

def show_account_info():
    """Zobrazí informace o účtu"""
    log_debug("show_account_info()")
    token, _ = check_prerequisites(silent=False)
    if not token: return
    info = ws_logic.get_user_info(token)
    if info:
        c = "lime" if info['is_vip'] else "red"
        txt = f"Uživatel: {info['username']}\nStav: [COLOR {c}]{'VIP AKTIVNÍ' if info['is_vip'] else 'NEAKTIVNÍ'}[/COLOR]\nExpirace: {info['expire']}"
        xbmcgui.Dialog().ok("Stav účtu", txt)
        log_debug("show_account_info() displayed")

def run_speed_test():
    """Spustí test rychlosti"""
    log_debug("run_speed_test()")
    token, _ = check_prerequisites()
    if not token: return
    pd = xbmcgui.DialogProgress()
    pd.create('Speed Test', 'Měřím rychlost stahování...')
    
    def update_progress(percent, max, msg=None, abort_check=False):
        if abort_check: return pd.iscanceled()
        display_msg = msg if msg else f"Měřím... {percent}%"
        pd.update(percent, display_msg)
        return pd.iscanceled()
        
    prumer, maximum = ws_logic.measure_download_speed(token, update_progress)
    pd.close()

    if prumer > 0:
        xbmcgui.Dialog().ok("Výsledek", f"Průměrná rychlost: [COLOR lime][B]{prumer} Mbps[/B][/COLOR]\nNejvyšší rychlost: [COLOR lime][B]{maximum} Mbps[/B][/COLOR]")
        log_debug(f"run_speed_test() result: avg={prumer}, max={maximum}")
    elif prumer == -2.0:
        xbmcgui.Dialog().ok("Chyba", "Chyba testu: Síťová chyba.")
        log_debug("run_speed_test() network error")
    else:
        xbmcgui.Dialog().ok("Chyba", "Chyba testu: Test byl zrušen.")
        log_debug("run_speed_test() aborted")

def main_menu():
    """Hlavní menu"""
    log_debug("main_menu()")
    create_list_item('Hledat vše', build_url({'mode':'search_all'}), {'icon': ICONS['SEARCH']})
    create_list_item('Filmy', build_url({'mode':'movies_menu'}), {'icon': ICONS['FILM']})
    create_list_item('Seriály', build_url({'mode':'tv_menu'}), {'icon': ICONS['FILM']})
    create_list_item('Historie', build_url({'mode':'history_menu'}), {'icon': ICONS['HISTORY']})
    create_list_item('Nastavení', build_url({'mode':'settings'}), {'icon': ICONS['SETTINGS']}, is_folder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def movies_menu():
    """Menu pro filmy"""
    log_debug("movies_menu()")
    create_list_item('Hledat filmy', build_url({'mode':'search_movies'}), {'icon': ICONS['SEARCH']})
    create_list_item('Nově nadabované (CZ)', build_url({'mode':'list_discover', 'type':'dubbed', 'media_type':'movie', 'tmdb_page':'1'}), {'icon': ICONS['CZ']})
    create_list_item('Nově s titulky (CZ)', build_url({'mode':'list_discover', 'type':'subtitled', 'media_type':'movie', 'tmdb_page':'1'}), {'icon': ICONS['TRANSCRIPT']})
    create_list_item('Nejpopulárnější', build_url({'mode':'list_tmdb', 'cat':'movie_popular', 'tmdb_page':'1'}), {'icon': ICONS['POPULAR']})
    create_list_item('Podle roku', build_url({'mode':'years_menu', 'media_type':'movie'}), {'icon': ICONS['CALENDAR']})
    create_list_item('Podle žánru', build_url({'mode':'genres_menu', 'media_type':'movie'}), {'icon': ICONS['BOOK']})
    xbmcplugin.endOfDirectory(HANDLE)

def tv_menu():
    """Menu pro seriály"""
    log_debug("tv_menu()")
    create_list_item('Hledat seriály', build_url({'mode':'search_tv'}), {'icon': ICONS['SEARCH']})
    create_list_item('Nově nadabované (CZ)', build_url({'mode':'list_discover', 'type':'dubbed', 'media_type':'tv', 'tmdb_page':'1'}), {'icon': ICONS['CZ']})
    create_list_item('Nově s titulky (CZ)', build_url({'mode':'list_discover', 'type':'subtitled', 'media_type':'tv', 'tmdb_page':'1'}), {'icon': ICONS['TRANSCRIPT']})
    create_list_item('Nejpopulárnější', build_url({'mode':'list_tmdb', 'cat':'tv_popular', 'tmdb_page':'1'}), {'icon': ICONS['POPULAR']})
    create_list_item('Podle roku', build_url({'mode':'years_menu', 'media_type':'tv'}), {'icon': ICONS['CALENDAR']})
    create_list_item('Podle žánru', build_url({'mode':'genres_menu', 'media_type':'tv'}), {'icon': ICONS['BOOK']})
    xbmcplugin.endOfDirectory(HANDLE)

def years_menu(media_type='movie'):
    """
    Menu s roky
    Args: media_type='movie' nebo 'tv'
    """
    log_debug(f"years_menu(media_type={media_type})")
    for y in range(datetime.datetime.now().year + 1, 1950, -1):
        create_list_item(str(y), build_url({'mode':'list_discover', 'type':'year', 'media_type':media_type, 'year':str(y), 'tmdb_page':'1'}))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(media_type='movie'):
    """
    Menu s žánry
    Args: media_type='movie' nebo 'tv'
    """
    log_debug(f"genres_menu(media_type={media_type})")
    for name, gid in tmdb_handler.GENRES.items():
        create_list_item(name, build_url({'mode':'list_discover', 'type':'genre', 'media_type':media_type, 'genre_id':str(gid), 'tmdb_page':'1'}))
    xbmcplugin.endOfDirectory(HANDLE)

def history_menu():
    """Menu pro historii"""
    log_debug("history_menu()")
    create_list_item('Pokračovat ve sledování', build_url({'mode':'list_history', 'history_filter':'resume'}), {'icon': ICONS['RESUME']})
    create_list_item('Historie zhlédnutých', build_url({'mode':'list_history', 'history_filter':'watched'}), {'icon': ICONS['WATCHED']})
    create_list_item('Historie vyhledávání', build_url({'mode':'history_search'}), {'icon': ICONS['SEARCH']})
    xbmcplugin.endOfDirectory(HANDLE)

def process_tmdb_item_thread(item, token, tmdb_key, is_search_all, strict_mode=None, history_filter=None):
    """
    Zpracuje jeden TMDb item (kontrola dostupnosti, jazyky atd.)
    Args: item={...}, token='...', tmdb_key='...', is_search_all=False, strict_mode='subtitled' nebo None
    Returns: dict s doplněnými údaji nebo None
    """
    log_debug(f"process_tmdb_item_thread(item_id={item.get('id')}, media_type={item.get('type')}, strict_mode={strict_mode})")
    if not item: 
        log_debug("process_tmdb_item_thread() return: None (no item)")
        return None
    item.setdefault('is_available', False)
    item.setdefault('lang_label', '')
    item.setdefault('year', '')
    item.setdefault('display_title', item.get('title', 'Unknown'))
    item.setdefault('genres', [])

    try:
        mt = item.get('type', 'movie')
        raw_title = item.get('title', '')
        
        is_cjk = bool(re.search(r'[\u4e00-\u9fff]', raw_title))
        clean_title = re.sub(r'^\[.*?\]\s*', '', raw_title)
        
        titles = [clean_title, item.get('original_title', '')]
        try:
            en_title = tmdb_handler.get_en_title(item['id'], mt, tmdb_key)
            if en_title and en_title not in titles: titles.append(en_title)
        except: pass
        
        if is_cjk:
            if en_title: display_title = en_title
            elif item.get('original_title') and not re.search(r'[\u4e00-\u9fff]', item.get('original_title', '')): display_title = item.get('original_title')
            else: display_title = clean_title
        else: display_title = clean_title

        if not item.get('year') or not item.get('poster') or not item.get('plot') or not item.get('genres'):
            try:
                details = tmdb_handler.get_details(item['id'], mt, tmdb_key)
                if details:
                    item.update(details)
                    if 'release_date' in details and details['release_date']:
                        item['year'] = details['release_date'][:4]
            except Exception as e:
                 log_debug(f"process_tmdb_item_thread() details fetch error: {e}")

        if history_filter and mt == 'tv':
            try:
                total_eps = item.get('episodes_count', 0)
                watched_count = ws_logic.get_series_progress_stats(item['id'])
                pct = int((watched_count / total_eps) * 100) if total_eps > 0 else 0
                item['series_percent'] = pct
                if history_filter == 'resume':
                    if pct == 0 or pct >= 100:
                        log_debug("process_tmdb_item_thread() return: None (filtered by resume)")
                        return None
                elif history_filter == 'watched':
                    if pct < 100:
                        log_debug("process_tmdb_item_thread() return: None (filtered by watched)")
                        return None
            except:
                log_debug("process_tmdb_item_thread() return: None (filter error)")
                return None
                
        avail = False
        lang_priority = {'CZ': 3, 'CZ TIT': 2, 'EN': 1}
        best_priority = 0
        best_lang_label = ""
        found_langs = []

        for q in titles[:3]:
            try:
                res = ws_logic.search_webshare_bulk(q, token, limit=20)
                if not res: continue
                
                for r in res:
                    fname = r.findtext("name")
                    is_valid = False
                    
                    if mt == 'movie':
                        is_valid = ws_logic.is_valid_file(fname, titles, 'movie', year=item.get('year'))
                    elif mt == 'tv':
                        is_valid = ws_logic.normalize_title(clean_title) in ws_logic.normalize_title(fname)
                    
                    if is_valid:
                        detected = ws_logic.detect_lang_label(fname)
                        found_langs.append(detected)
                        
                        if strict_mode == 'subtitled' and detected == "CZ":
                            log_debug("process_tmdb_item_thread() return: None (strict subtitled, found CZ dub)")
                            return None 
                        
                        avail = True
                        current_p = lang_priority.get(detected, 1)
                        if current_p > best_priority:
                            best_priority = current_p
                            best_lang_label = detected
                if mt == 'movie' and best_priority == 3: break
            except Exception as e:
                log_debug(f"process_tmdb_item_thread() search error: {e}")
            
        if strict_mode == 'subtitled' and best_lang_label != "CZ TIT":
            log_debug("process_tmdb_item_thread() return: None (strict subtitled, not CZ TIT)")
            return None

        if mt == 'tv' and avail:
            u_langs = list(set(found_langs))
            u_langs.sort(key=lambda x: ws_logic.get_language_priority(x), reverse=True)
            best_lang_label = ", ".join(u_langs)

        item['is_available'] = avail
        item['lang_label'] = best_lang_label
        item['display_title'] = f"[{'Film' if mt=='movie' else 'Seriál'}] {display_title}" if is_search_all else display_title
        
        if mt == 'tv' and 'series_percent' not in item:
            try:
                total_eps = item.get('episodes_count', 0)
                watched_count = ws_logic.get_series_progress_stats(item['id'])
                if total_eps > 0 and watched_count > 0:
                    item['series_percent'] = int((watched_count / total_eps) * 100)
            except: pass

        log_debug(f"process_tmdb_item_thread() return: item (available={avail}, lang={best_lang_label})")
        return item
    except Exception as e:
        log_debug(f"process_tmdb_item_thread() exception: {e}")
        return item

def render_content_list(results, token, tmdb_key, strict_mode=None, history_filter=None):
    """
    Vykreslí seznam obsahu
    Args: results=[...], token='...', tmdb_key='...', strict_mode=None, history_filter=None
    """
    log_debug(f"render_content_list(results_count={len(results) if results else 0}, strict_mode={strict_mode}, history_filter={history_filter})")
    if not results: 
        log_debug("render_content_list() no results")
        return
        
    is_search_all = ARGS.get('mode', [''])[0] == 'search_all'
    
    items_to_process = [i for i in results if 'is_available' not in i]
    already_processed = [i for i in results if 'is_available' in i]
    
    if items_to_process:
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
            futures = {ex.submit(process_tmdb_item_thread, i, token, tmdb_key, is_search_all, strict_mode, history_filter): i for i in items_to_process}
            for f in concurrent.futures.as_completed(futures):
                try:
                    res = f.result()
                    if res: already_processed.append(res)
                except Exception as ex:
                    log_debug(f"render_content_list() thread error: {ex}")
    
    already_processed.sort(key=lambda x: str(x.get('year') or ''), reverse=True)

    for i in already_processed:
        mt = i.get('type', 'movie')
        avail = i.get('is_available')
        color = "white" if avail else "gray"
        
        lang_str = f" [B]({i['lang_label']})[/B]" if avail and i.get('lang_label') else " (Nedostupný)" if not avail else ""

        progress_str = ""
        uid = i.get('unique_id', str(i['id']))
        overlay_icon = None

        if mt == 'tv':
            pct = i.get('series_percent', 0)
            if pct > 0:
                progress_str = f" [COLOR gray]({pct}%)[/COLOR]"
                overlay_icon = ICONS['OVERLAY_WATCHED'] if pct >= 100 else ICONS['OVERLAY_RESUME']
        else:
            st = ws_logic.get_watched_status(uid)
            if st:
                if st.get('status') == 'resume':
                    progress_str = f" [COLOR gray]({int(st.get('percentage', 0))}%)[/COLOR]"
                    overlay_icon = ICONS['OVERLAY_RESUME']
                elif st.get('status') == 'watched':
                    progress_str = " [COLOR gray]Zhlédnuto[/COLOR]"
                    overlay_icon = ICONS['OVERLAY_WATCHED']

        y_str = str(i.get('year', ''))
        year_disp = f" ({y_str})" if y_str.isdigit() else ""
        label = f"[COLOR {color}]{i.get('display_title')}{year_disp}{lang_str}{progress_str}[/COLOR]"
        
        cz_tit = i.get('title_cz', i.get('title',''))
        en_tit = i.get('title_en', '')
        genres_str = ", ".join(i.get('genres', []))

        desc = f"{cz_tit} | [COLOR gray]{en_tit}[/COLOR]\n{i.get('studio','')}\nVydáno: {ws_logic.format_date_cz(i.get('release_date',''))}\n\n"
        if mt == 'movie': desc += f"Rozpočet:   {ws_logic.format_currency(i.get('budget'))}\nTržby:      {ws_logic.format_currency(i.get('revenue'))}\n"
        desc += f"{genres_str}\n\n"
        desc += f"{i.get('plot','')}\n\nHrají: {', '.join(i.get('cast', []))}"

        info = {
            'title': i.get('display_title'), 'plot': desc, 'rating': i.get('rating', 0),
            'year': int(y_str) if y_str.isdigit() else 0, 'cast': i.get('cast', []), 'genres': i.get('genres', [])
        }
        
        p = i.get('poster') or ICONS['DEF_VIDEO']
        art = {'icon': overlay_icon if overlay_icon else p, 'thumb': p, 'poster': p, 'fanart': i.get('fanart','')}
        
        if mt == 'movie':
            url = build_url({'mode': 'resolve_content', 'media_type': 'movie', 'id': i['id'], 't': i['title'], 'ot': i.get('original_title',''), 'poster': p})
            create_list_item(label, url, art, info, is_playable=True)
        else:
            url = build_url({'mode': 'list_seasons', 'id': i['id'], 't': i['title'], 'ot': i.get('original_title','')})
            create_list_item(label, url, art, info, is_folder=True)
    
    log_debug(f"render_content_list() rendered {len(already_processed)} items")

def list_discover(type_filter, media_type, tmdb_page, year=None, genre_id=None):
    """
    Seznam z TMDb discover endpoint
    Args: type_filter='dubbed' nebo 'subtitled' nebo 'year' nebo 'genre', media_type='movie', tmdb_page='1'
    """
    log_debug(f"list_discover(type_filter={type_filter}, media_type={media_type}, tmdb_page={tmdb_page}, year={year}, genre_id={genre_id})")
    token, k = check_prerequisites()
    if not token: return
    page = int(tmdb_page)
    items_per_page = int(get_setting('items_per_page'))
    params = {}
    strict_mode = None
    
    if type_filter == 'dubbed':
        params = {'sort_by': 'primary_release_date.desc' if media_type == 'movie' else 'first_air_date.desc', 'vote_count.gte': '5'}
    elif type_filter == 'subtitled':
        params = {'sort_by': 'vote_count.desc'}
        strict_mode = 'subtitled'
    elif type_filter == 'year':
        params = {('primary_release_year' if media_type == 'movie' else 'first_air_date_year'): year, 'sort_by': 'popularity.desc'}
    elif type_filter == 'genre':
        params = {'with_genres': genre_id, 'sort_by': 'popularity.desc'}
    
    fetcher = lambda page: tmdb_handler.discover(k, type=media_type, params=params, page=page)
    items, np, _ = tmdb_handler.smart_pagination_fetch(fetcher, k, page, 0, items_per_page, False, token, None, media_type)
    render_content_list(items, token, k, strict_mode=strict_mode)
    
    if np > page:
        create_list_item("Další >>", build_url({'mode':'list_discover', 'type':type_filter, 'media_type':media_type, 'tmdb_page':str(page+1), 'year':year, 'genre_id':genre_id}))
            
    xbmcplugin.endOfDirectory(HANDLE)
    log_debug("list_discover() completed")

def list_tmdb(cat, tmdb_page):
    """
    Seznam populárního obsahu z TMDb
    Args: cat='movie_popular' nebo 'tv_popular', tmdb_page='1'
    """
    log_debug(f"list_tmdb(cat={cat}, tmdb_page={tmdb_page})")
    token, k = check_prerequisites()
    if not token: return
    page = int(tmdb_page)
    items_per_page = int(get_setting('items_per_page'))
    mt = 'movie' if 'movie' in cat else 'tv'
    api_cat = 'popular' if 'popular' in cat else 'now_playing'
    fetcher = lambda page: tmdb_handler.get_popular(k, mt, api_cat, page=page)
    items, np, _ = tmdb_handler.smart_pagination_fetch(fetcher, k, page, 0, items_per_page, False, token, None, mt)
    render_content_list(items, token, k)
    if np > page:
        create_list_item("Další >>", build_url({'mode':'list_tmdb', 'cat':cat, 'tmdb_page':str(np)}))
    xbmcplugin.endOfDirectory(HANDLE)
    log_debug("list_tmdb() completed")

def list_history(history_filter='resume'):
    """
    Seznam z historie
    Args: history_filter='resume' nebo 'watched'
    """
    log_debug(f"list_history(history_filter={history_filter})")
    token, k = check_prerequisites()
    if not token: return
    items = ws_logic.get_history_items(filter_type=history_filter)
    if not items:
        xbmcgui.Dialog().notification('Info', 'Prázdná historie', xbmcgui.NOTIFICATION_INFO)
        log_debug("list_history() empty history")
        return
    tmdb_res = []
    for i in items:
        rid = str(i['id'])
        cid = rid.split('_')[0] if '_' in rid else rid
        yr = i.get('year')
        yr = '' if str(yr)=='None' else yr
        tmdb_res.append({'id': int(cid), 'type': i['type'], 'title': i['title'], 'original_title': i['title'], 'year': yr, 'poster': i.get('poster',''), 'fanart':'', 'unique_id': i['unique_id']})
    render_content_list(tmdb_res, token, k, history_filter=history_filter)
    xbmcplugin.endOfDirectory(HANDLE)
    log_debug("list_history() completed")

def check_season_details(tid, s_num, clean_t, token):
    """
    Kontroluje detaily sezóny (dostupné epizody a jazyky)
    Args: tid=123, s_num=1, clean_t='Show Name', token='...'
    Returns: (season_num, available_count, languages_str, found_episodes_set)
    """
    log_debug(f"check_season_details(tid={tid}, s_num={s_num}, clean_t={clean_t})")
    q = f"{clean_t} s{str(s_num).zfill(2)}"
    files = ws_logic.search_webshare_bulk(q, token, limit=100)
    ep_langs = {}
    found_eps = set()
    
    for f in files:
        fname = f.findtext("name")
        m = re.search(r'(?:e|x)(\d+)', fname.lower())
        if m:
            ep_n = int(m.group(1))
            found_eps.add(ep_n)
            lang = ws_logic.detect_lang_code(fname)
            if ep_n not in ep_langs:
                ep_langs[ep_n] = []
            ep_langs[ep_n].append(lang)

    all_langs_in_season = []
    for ep_n, langs in ep_langs.items():
        best = "EN"
        if "CZ" in langs: best = "CZ"
        elif "CZ TIT" in langs: best = "CZ TIT"
        elif "SK" in langs: best = "SK"
        elif langs: best = langs[0]
        all_langs_in_season.append(best)
        
    unique_season_langs = list(set(all_langs_in_season))
    unique_season_langs.sort(key=lambda x: ws_logic.get_language_priority(x), reverse=True)
    lang_str = ", ".join(unique_season_langs)
    
    log_debug(f"check_season_details() return: {len(found_eps)} episodes, langs={lang_str}")
    return s_num, len(found_eps), lang_str, found_eps

def list_seasons(tid, t, ot):
    """
    Seznam sezón seriálu
    Args: tid=123, t='Show Name', ot='Original Name'
    """
    log_debug(f"list_seasons(tid={tid}, t={t})")
    token, k = check_prerequisites()
    det = tmdb_handler.get_details(tid, 'tv', k)
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    
    s_data = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futures = {ex.submit(check_season_details, tid, i, clean_t, token): i for i in range(1, det.get('seasons_count', 0)+1)}
        for f in concurrent.futures.as_completed(futures):
            try:
                s, c, l, eps = f.result()
                s_data[s] = {'count':c, 'lang':l, 'eps':eps}
            except Exception as e:
                log_debug(f"list_seasons() season check error: {e}")

    for i in range(1, det.get('seasons_count', 0)+1):
        d = s_data.get(i, {'count':0, 'lang':'', 'eps':set()})
        avail_count = len(d['eps'])
        
        watched_count = 0
        if avail_count > 0:
            for ep_num in d['eps']:
                uid = f"{tid}_S{i}E{ep_num}"
                st = ws_logic.get_watched_status(uid)
                if st and st.get('status') == 'watched': watched_count += 1
        
        lang_tag = f" [B]({d['lang']})[/B]" if d['lang'] else ""
        pct_str = ""
        overlay = None
        
        if avail_count == 0:
            label = f"[COLOR gray]Série {i} (Nedostupné)[/COLOR]"
        else:
            if watched_count > 0:
                p = int((watched_count / avail_count) * 100)
                pct_str = f" [COLOR gray]({p}%)[/COLOR]"
                overlay = ICONS['OVERLAY_WATCHED'] if p>=100 else ICONS['OVERLAY_RESUME']
            label = f"Série {i}{lang_tag}{pct_str}"
            
        art = {'icon': overlay if overlay else ICONS['DEF_FOLDER']}
        create_list_item(label, build_url({'mode':'list_episodes','id':tid,'s':i,'t':t,'ot':ot}), art, is_folder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)
    log_debug("list_seasons() completed")

def list_episodes(tid, s, t, ot):
    """
    Seznam epizod sezóny
    Args: tid=123, s=1, t='Show Name', ot='Original Name'
    """
    log_debug(f"list_episodes(tid={tid}, s={s}, t={t})")
    token, k = check_prerequisites()
    eps = tmdb_handler.get_season_episodes(tid, s, k)
    if not eps:
        xbmcplugin.endOfDirectory(HANDLE)
        log_debug("list_episodes() no episodes")
        return
    
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    all_files = []
    for tit in [clean_t, ot]:
        if tit: all_files.extend(ws_logic.search_webshare_bulk(f"{tit} s{str(s).zfill(2)}", token, 150))
    
    for e in eps:
        ep_uid = f"{tid}_S{s}E{e['episode']}"
        best_lang = ""
        has_f = False
        curr_p = 0
        prio = {'CZ':3, 'CZ TIT':2, 'SK':1.5, 'EN':1}
        
        for f in all_files:
            fn = f.findtext("name")
            if ws_logic.is_valid_file(fn, [clean_t, ot], 'tv', season=s, episode=e['episode']):
                has_f = True
                l = ws_logic.detect_lang_code(fn)
                p = prio.get(l, 0.5)
                if p > curr_p:
                    curr_p = p
                    best_lang = l
        
        st = ws_logic.get_watched_status(ep_uid)
        prog = ""
        overlay = None
        if st:
            if st.get('status') == 'watched':
                prog = " [COLOR gray]Zhlédnuto[/COLOR]"
                overlay = ICONS['OVERLAY_WATCHED']
            elif st.get('status') == 'resume':
                prog = f" [COLOR gray]({int(st.get('percentage'))}%)[/COLOR]"
                overlay = ICONS['OVERLAY_RESUME']
        
        lang_str = f" [B]({best_lang})[/B]" if has_f and best_lang else ""
        label = f"{e['episode']}. {e['name']}{lang_str}{prog}"
        art = {'thumb': e['thumb'], 'icon': overlay if overlay else (e['thumb'] or ICONS['DEF_VIDEO'])}
        info = {'title': e['name'], 'plot': e['overview']}
        
        if has_f:
            create_list_item(label, build_url({'mode':'resolve_content','media_type':'tv','id':tid,'s':s,'e':e['episode'],'t':t,'ot':ot,'en':e['name']}), art, info, is_playable=False)
        else:
            create_list_item(f"[COLOR gray]{label} (Nedostupné)[/COLOR]", build_url({'mode':'ignore'}), art, info)
    
    xbmcplugin.endOfDirectory(HANDLE)
    log_debug("list_episodes() completed")

def select_and_play_file(files, display_title, uid, media_type, poster=None):
    """
    Zobrazí výběr souboru a přehraje vybraný
    Args: files=[...], display_title='Title', uid='123', media_type='movie', poster='...'
    """
    log_debug(f"select_and_play_file(files_count={len(files)}, display_title={display_title}, uid={uid}, media_type={media_type})")
    
    if not files:
        xbmcgui.Dialog().ok("Info", "Soubory nenalezeny.")
        log_debug("select_and_play_file() no files")
        return
    
    files.sort(key=lambda x: int(x.findtext("size") or 0), reverse=True)
    l_items = []
    
    for f in files:
        n = f.findtext("name")
        qk, ql = ws_logic.detect_quality_label(n)
        ll = ws_logic.detect_lang_code(n)
        
        if media_type == 'movie':
            c_q = "red" if "4K" in ql else "lime" if "1080p" in ql else "yellow"
            c_l = "gold" if "CZ" in ll else "white"
            label = f"[COLOR {c_q}]{ql}[/COLOR] | [COLOR {c_l}]{ll}[/COLOR] | {ws_logic.format_size(f.findtext('size'))} | {n}"
            icon = ICONS['4K'] if qk=="4k" else ICONS['1080'] if qk=="1080p" else ICONS['720'] if qk=="720p" else ICONS['SD']
        else:
            label = f"{ql} | {ll} | {ws_logic.format_size(f.findtext('size'))} | {n}"
            icon = ICONS['DEF_VIDEO']
        
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': icon})
        l_items.append(li)
    
    sel = xbmcgui.Dialog().select("Vyberte kvalitu" if media_type == 'movie' else "Vyberte verzi", l_items)
    
    if sel >= 0:
        f = files[sel]
        play_direct(f.findtext("ident"), display_title, uid, 0, media_type, display_title, f.findtext("ident"), f.findtext("name"), poster=poster)
        log_debug(f"select_and_play_file() selected file index {sel}")
    else:
        log_debug("select_and_play_file() cancelled")

def resolve_content(media_type, tid, t, ot, s=None, e=None, en=None, poster=None):
    """
    Univerzální resolve pro filmy i epizody
    Args: media_type='movie', tid=123, t='Title', ot='Original'
    Args: media_type='tv', tid=123, s=1, e=5, t='Show', ot='Original', en='Episode Name'
    """
    log_debug(f"resolve_content(media_type={media_type}, tid={tid}, t={t}, s={s}, e={e})")
    token, k = check_prerequisites()
    if not token: return
    
    clean_t = re.sub(r'^\[.*?\]\s*', '', t)
    
    if media_type == 'tv':
        ep_uid = f"{tid}_S{s}E{e}"
        display_title = f"{clean_t} - {en}"
    else:
        ep_uid = str(tid)
        display_title = clean_t
    
    last_id, last_fn, resume = ws_logic.get_last_played_file(ep_uid)
    if last_id and xbmcgui.Dialog().yesno("Pokračovat?", f"Přehrát naposledy zvolený soubor?\n{last_fn}"):
        play_direct(last_id, display_title, ep_uid, resume, media_type, display_title, last_id, last_fn, poster=poster)
        log_debug("resolve_content() resumed last file")
        return
    
    titles = [clean_t, ot]
    if media_type == 'movie':
        try:
            en_title = tmdb_handler.get_en_title(tid, 'movie', k)
            if en_title: titles.append(en_title)
        except: pass
    
    found = []
    if media_type == 'tv':
        qs = ws_logic.generate_episode_queries([clean_t, ot], s, e)
        for q in qs: found.extend(ws_logic.search_webshare_bulk(q, token, 30))
        valid = [f for f in found if ws_logic.is_valid_file(f.findtext("name"), [clean_t, ot], 'tv', season=s, episode=e)]
    else:
        for q in titles: found.extend(ws_logic.search_webshare_bulk(q, token, 40))
        det = tmdb_handler.get_details(tid, 'movie', k)
        year = det.get('release_date', '')[:4]
        valid = [f for f in found if ws_logic.is_valid_file(f.findtext("name"), titles, 'movie', year=year)]
    
    select_and_play_file(valid, display_title, ep_uid, media_type, poster)
    log_debug("resolve_content() completed")

def play_direct(ident, title, uid, resume, mt, t_val, ident_val, fn_val, year=None, poster=None):
    """
    Přímé přehrání souboru
    Args: ident='abc123', title='Title', uid='123', resume=300, mt='movie'
    """
    log_debug(f"play_direct(ident={ident}, title={title}, uid={uid}, resume={resume}, mt={mt})")
    token, _ = check_prerequisites(silent=True)
    link = ws_logic.get_link(ident, token)
    
    if link:
        data = {"id": uid, "type": mt, "title": t_val, "ident": ident_val, "fname": fn_val, "year": year, "poster": poster}
        CACHE_WINDOW.setProperty('ws_monitor_data', json.dumps(data))
        li = xbmcgui.ListItem(path=link)
        set_video_info_tag(li, {'title': title})
        if float(resume or 0) > 0: li.setProperties({'StartOffset': str(resume)})
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        log_debug("play_direct() playback started")
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        log_debug("play_direct() failed - no link")

def search_all():
    """Hledání všeho"""
    log_debug("search_all()")
    kb = xbmc.Keyboard('', 'Hledat vše')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _perform_search(kb.getText(), 'all')

def search_movies():
    """Hledání filmů"""
    log_debug("search_movies()")
    kb = xbmc.Keyboard('', 'Hledat filmy')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _perform_search(kb.getText(), 'movie')

def search_tv():
    """Hledání seriálů"""
    log_debug("search_tv()")
    kb = xbmc.Keyboard('', 'Hledat seriály')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _perform_search(kb.getText(), 'tv')

def _perform_search(query, filter_type):
    """
    Provede vyhledávání
    Args: query='matrix', filter_type='all' nebo 'movie' nebo 'tv'
    """
    log_debug(f"_perform_search(query={query}, filter_type={filter_type})")
    ws_logic.add_to_search_history(query)
    token, k = check_prerequisites()
    if token:
        mode = 'movie' if filter_type == 'movie' else 'tv' if filter_type == 'tv' else 'multi'
        res = tmdb_handler.search(query, k, search_type=mode)
        final = [item for item in res if filter_type == 'all' or item.get('type') == filter_type]
        render_content_list(final, token, k)
        xbmcplugin.endOfDirectory(HANDLE)
        log_debug(f"_perform_search() completed with {len(final)} results")

def history_search():
    """Historie vyhledávání"""
    log_debug("history_search()")
    h = ws_logic.load_history('search_history.json')
    if isinstance(h, list):
        for q in h: create_list_item(q, build_url({'mode':'search_query', 'query':q}), {'icon': ICONS['SEARCH']})
    xbmcplugin.endOfDirectory(HANDLE)
    log_debug("history_search() completed")

def search_query(q):
    """
    Vyhledání podle dotazu z historie
    Args: q='matrix'
    """
    log_debug(f"search_query(q={q})")
    _perform_search(q, 'all')

# ROUTER
mode = ARGS.get('mode', [None])[0]
p = {k: ARGS[k][0] for k in ARGS}
log_debug(f"Router: mode={mode}, params={list(p.keys())}")

if mode is None:
    main_menu()
elif mode == 'settings':
    ADDON.openSettings()
elif mode == 'show_account_info':
    show_account_info()
elif mode == 'run_speed_test':
    run_speed_test()
elif mode == 'clear_history':
    ws_logic.clear_search_history()
elif mode == 'clear_watched_history':
    ws_logic.clear_watched_history()
elif mode == 'search_all':
    search_all()
elif mode == 'search_movies':
    search_movies()
elif mode == 'search_tv':
    search_tv()
elif mode == 'movies_menu':
    movies_menu()
elif mode == 'tv_menu':
    tv_menu()
elif mode == 'years_menu':
    years_menu(p.get('media_type', 'movie'))
elif mode == 'genres_menu':
    genres_menu(p.get('media_type', 'movie'))
elif mode == 'history_menu':
    history_menu()
elif mode == 'list_tmdb':
    list_tmdb(p['cat'], p.get('tmdb_page', '1'))
elif mode == 'list_discover':
    list_discover(p.get('type'), p.get('media_type'), p.get('tmdb_page', '1'), p.get('year'), p.get('genre_id'))
elif mode == 'list_history':
    list_history(p.get('history_filter', 'resume'))
elif mode == 'search_query':
    search_query(p['query'])
elif mode == 'history_search':
    history_search()
elif mode == 'resolve_content':
    resolve_content(
        p['media_type'],
        p['id'],
        p['t'],
        p.get('ot', ''),
        s=p.get('s'),
        e=p.get('e'),
        en=p.get('en'),
        poster=p.get('poster')
    )
elif mode == 'list_seasons':
    list_seasons(p['id'], p['t'], p.get('ot', ''))
elif mode == 'list_episodes':
    list_episodes(p['id'], p['s'], p['t'], p.get('ot', ''))